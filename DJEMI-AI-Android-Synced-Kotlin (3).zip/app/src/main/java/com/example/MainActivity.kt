package com.example

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.auth.AuthManager
import com.example.ui.components.AppBottomNavigation
import com.example.ui.components.AppHeader
import com.example.ui.screens.CriteriaScreen
import com.example.ui.screens.GradebookScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.SeatingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SignInScreen
import com.example.ui.theme.DjemiTheme
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.MainViewModel
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val authManager by lazy { AuthManager(applicationContext) }
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val currentUser by authManager.authStateFlow().collectAsStateWithLifecycle(initialValue = authManager.currentUser)
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
            val accentColorVal by viewModel.accentColor.collectAsStateWithLifecycle()

            LaunchedEffect(currentUser) {
                val user = currentUser
                if (user != null) {
                    viewModel.startSyncForUser(user.uid)
                } else {
                    viewModel.stopSync()
                }
            }

            DjemiTheme(
                darkTheme = isDarkMode,
                accentColor = Color(accentColorVal)
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainApp(
                        viewModel = viewModel,
                        authManager = authManager,
                        currentUser = currentUser
                    )
                }
            }
        }
    }
}

@Composable
fun MainApp(
    viewModel: MainViewModel,
    authManager: AuthManager,
    currentUser: FirebaseUser?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val currentSection by viewModel.currentSection.collectAsStateWithLifecycle()
    val teacherProfile by viewModel.teacherProfile.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.toastMessage.collectLatest { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    // Back button handling: return to Overview tab if in another tab
    if (currentTab != AppNavTab.OVERVIEW) {
        BackHandler {
            viewModel.selectTab(AppNavTab.OVERVIEW)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            AppHeader(
                sectionName = currentSection?.name ?: "1م1",
                schoolYear = currentSection?.year ?: teacherProfile.year,
                subject = currentSection?.subject ?: teacherProfile.subject,
                onOpenSettings = { viewModel.selectTab(AppNavTab.SETTINGS) }
            )
        },
        bottomBar = {
            AppBottomNavigation(
                currentTab = currentTab,
                onTabSelected = { tab -> viewModel.selectTab(tab) }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppNavTab.OVERVIEW -> OverviewScreen(viewModel = viewModel)
                AppNavTab.SEATING -> SeatingScreen(viewModel = viewModel)
                AppNavTab.GRADEBOOK -> GradebookScreen(viewModel = viewModel)
                AppNavTab.CRITERIA -> CriteriaScreen(viewModel = viewModel)
                AppNavTab.SETTINGS -> SettingsScreen(
                    viewModel = viewModel,
                    currentAccountEmail = currentUser?.email ?: currentUser?.displayName,
                    onSignIn = {
                        val activity = context as? Activity
                        if (activity != null) {
                            scope.launch {
                                authManager.signInWithGoogle(activity)
                            }
                        }
                    },
                    onSignOut = if (currentUser != null) {
                        {
                            scope.launch {
                                authManager.signOut()
                            }
                        }
                    } else null
                )
            }
        }
    }
}
