package com.example.util

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.example.data.model.AssessmentCriterion
import com.example.data.model.GradebookRow
import com.example.data.model.Section
import com.example.data.model.Student
import com.example.data.model.TeacherProfile

object PrintHelper {

    /**
     * طباعة قائمة تلاميذ القسم بتنسيق رسمي متوافق مع وزارة التربية الوطنية الجزائرية
     * يتيح للمستخدم الطباعة المباشرة عبر الطابعة أو الحفظ كملف PDF
     */
    fun printStudentList(
        context: Context,
        section: Section,
        teacherProfile: TeacherProfile,
        students: List<Student>
    ) {
        val htmlContent = buildStudentListHtml(section, teacherProfile, students)
        printHtml(context, "قائمة_تلاميذ_${section.name}", htmlContent)
    }

    /**
     * طباعة كشف نقاط التقويم المستمر ودفتر التنقيط الرسمي
     */
    fun printGradebook(
        context: Context,
        section: Section,
        teacherProfile: TeacherProfile,
        rows: List<GradebookRow>
    ) {
        val htmlContent = buildGradebookHtml(section, teacherProfile, rows)
        printHtml(context, "دفتر_تنقيط_${section.name}", htmlContent)
    }

    /**
     * طباعة شبكة معايير التقويم المستمر فارغة بدون نقاط مع أسماء التلاميذ
     * لإتاحة التنقيط اليدوي في القسم أثناء الأنشطة الصفية
     */
    fun printBlankAssessmentGrid(
        context: Context,
        section: Section,
        teacherProfile: TeacherProfile,
        criteria: List<AssessmentCriterion>,
        students: List<Student>
    ) {
        val htmlContent = buildBlankAssessmentGridHtml(section, teacherProfile, criteria, students)
        printHtml(context, "شبكة_تقويم_فارغة_${section.name}", htmlContent)
    }

    /**
     * طباعة دفتر التنقيط فارغ مع أسماء التلاميذ بدون نقاط
     * لملء النقاط يدوياً (التقويم المستمر، الفرض، الاختبار، المعدل)
     */
    fun printBlankGradebook(
        context: Context,
        section: Section,
        teacherProfile: TeacherProfile,
        students: List<Student>
    ) {
        val htmlContent = buildBlankGradebookHtml(section, teacherProfile, students)
        printHtml(context, "دفتر_تنقيط_فارغ_${section.name}", htmlContent)
    }

    /**
     * طباعة مخطط الجلوس بنفس شكل الواجهة (السبورة الخضراء + مكتب الأستاذ الذهبي + طاولات دائرية)
     * مع إمكانية التحكم في تكبير/تصغير الطاولات والمخطط (deskScale & scalePercent)
     */
    fun printSeatingChart(
        context: Context,
        section: Section,
        profile: TeacherProfile,
        seats: List<String>,
        scalePercent: Int = 95,
        deskScale: Int = section.deskScale
    ) {
        val htmlContent = buildVisualSeatingHtml(section, profile, seats, scalePercent, deskScale)
        printHtml(context, "مخطط_جلوس_${section.name}", htmlContent)
    }

    private fun buildVisualSeatingHtml(
        section: Section,
        profile: TeacherProfile,
        seats: List<String>,
        scalePercent: Int,
        deskScale: Int
    ): String {
        val totalDesks = section.rows * section.cols
        val desksHtml = StringBuilder()
        for (deskIdx in 0 until totalDesks) {
            val s1 = seats.getOrNull(deskIdx * 2)?.ifBlank { "مقعد شاغر" } ?: "مقعد شاغر"
            val s2 = seats.getOrNull(deskIdx * 2 + 1)?.ifBlank { "مقعد شاغر" } ?: "مقعد شاغر"
            desksHtml.append(
                """
                <div class="desk-card">
                    <div class="desk-title">طاولة ${deskIdx + 1}</div>
                    <div class="seats-row">
                        <div class="seat-chip">${s1}</div>
                        <div class="seat-chip">${s2}</div>
                    </div>
                </div>
                """.trimIndent()
            )
        }
        val teacherDesk = """<div class="teacher-desk">مكتب الأستاذ</div>"""
        val chalkboard = """<div class="chalkboard">السبورة</div>"""
        val frontBar = if (section.deskSide == "left") "$chalkboard$teacherDesk" else "$teacherDesk$chalkboard"
        val fontPx = (11.5 * (deskScale / 100.0)).coerceIn(8.0, 16.0)
        val gridZoom = (scalePercent / 100.0).coerceIn(0.6, 1.25)

        return """
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
            <meta charset="utf-8">
            <title>مخطط الجلوس - قسم ${section.name}</title>
            <style>
                @page { size: A4 landscape; margin: 7mm; }
                body {
                    font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
                    direction: rtl;
                    margin: 0;
                    padding: 6px;
                    background: #fff;
                    transform: scale(${gridZoom});
                    transform-origin: top center;
                    -webkit-print-color-adjust: exact;
                    print-color-adjust: exact;
                }
                .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 4px; margin-bottom: 6px; font-size: 11px; font-weight: bold; }
                .meta { display: flex; justify-content: space-between; font-size: 10px; font-weight: bold; background: #f8fafc; border: 1px solid #000; padding: 4px 8px; margin-bottom: 8px; border-radius: 4px; }
                .front-bar { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
                .chalkboard { flex: 1; background: #064e3b; border: 4px solid #b45309; color: #fff; font-weight: 900; text-align: center; padding: 7px 12px; border-radius: 10px; font-size: 13px; letter-spacing: 1px; }
                .teacher-desk { width: 120px; background: #fef3c7; border: 2px solid #fcd34d; color: #78350f; font-weight: 900; text-align: center; padding: 7px 10px; border-radius: 10px; font-size: 11px; }
                .grid { display: grid; grid-template-columns: repeat(${section.cols}, minmax(0, 1fr)); gap: 8px; }
                .desk-card { background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 12px; padding: 7px; }
                .desk-title { text-align: center; font-size: 9.5px; color: #64748b; font-weight: bold; margin-bottom: 5px; }
                .seats-row { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; }
                .seat-chip { background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 6px 4px; text-align: center; font-weight: 800; font-size: ${fontPx}px; color: #0f172a; }
            </style>
        </head>
        <body>
            <div class="header">الجمهورية الجزائرية الديمقراطية الشعبية · وزارة التربية الوطنية · مخطط جلوس التلاميذ (حجرة ${section.roomNumber})</div>
            <div class="meta">
                <span>المؤسسة: ${profile.schoolName}</span>
                <span>الأستاذ(ة): ${profile.teacher}</span>
                <span>القسم: ${section.name} (${section.level})</span>
                <span>المادة: ${section.subject}</span>
                <span>السنة: ${section.year}</span>
            </div>
            <div class="front-bar">$frontBar</div>
            <div class="grid">$desksHtml</div>
        </body>
        </html>
        """.trimIndent()
    }

    private fun printHtml(context: Context, jobTitle: String, html: String) {
        try {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
            if (printManager == null) {
                Toast.makeText(context, "خدمة الطباعة غير متوفرة على هذا الجهاز", Toast.LENGTH_LONG).show()
                return
            }

            val webView = WebView(context)
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    try {
                        val printAdapter = webView.createPrintDocumentAdapter(jobTitle)
                        val printAttributes = PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build()
                        printManager.print(jobTitle, printAdapter, printAttributes)
                    } catch (e: Exception) {
                        Toast.makeText(context, "تعذر بدء عملية الطباعة: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            webView.loadDataWithBaseURL(null, html, "text/html; charset=utf-8", "UTF-8", null)
        } catch (e: Exception) {
            Toast.makeText(context, "خطأ أثناء تجهيز الطباعة: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildStudentListHtml(
        section: Section,
        profile: TeacherProfile,
        students: List<Student>
    ): String {
        val rowsHtml = StringBuilder()
        students.forEachIndexed { index, s ->
            rowsHtml.append(
                """
                <tr>
                    <td class="num">${index + 1}</td>
                    <td class="mat">${s.matricule.ifBlank { "—" }}</td>
                    <td class="name">${s.fullName}</td>
                    <td class="birth">${s.birthDate.ifBlank { "—" }}</td>
                    <td class="status">${s.status.ifBlank { "متمدرس" }}</td>
                    <td class="obs"></td>
                </tr>
                """.trimIndent()
            )
        }

        return """
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
            <meta charset="utf-8">
            <title>قائمة تلاميذ قسم ${section.name}</title>
            <style>
                @page {
                    size: A4 portrait;
                    margin: 12mm 10mm 12mm 10mm;
                }
                body {
                    font-family: 'Cairo', 'Amiri', 'Segoe UI', Tahoma, sans-serif;
                    direction: rtl;
                    text-align: right;
                    color: #111827;
                    margin: 0;
                    padding: 8px;
                    background: #fff;
                    font-size: 13px;
                }
                .header-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 12px;
                }
                .header-table td {
                    border: none;
                    vertical-align: top;
                    padding: 2px 4px;
                }
                .republic {
                    text-align: center;
                    font-weight: bold;
                    font-size: 15px;
                    margin-bottom: 6px;
                }
                .ministry {
                    text-align: center;
                    font-size: 13px;
                    color: #374151;
                    margin-bottom: 12px;
                }
                .title-box {
                    text-align: center;
                    border: 2px solid #1e3a8a;
                    background-color: #f0fdf4;
                    padding: 8px;
                    border-radius: 6px;
                    font-size: 16px;
                    font-weight: bold;
                    color: #1e3a8a;
                    margin: 10px auto;
                    width: 75%;
                }
                .meta-table {
                    width: 100%;
                    margin-bottom: 12px;
                    font-size: 12px;
                }
                .meta-table td {
                    padding: 4px 6px;
                    background: #f8fafc;
                    border: 1px solid #e2e8f0;
                }
                table.data-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 8px;
                }
                table.data-table th, table.data-table td {
                    border: 1px solid #334155;
                    padding: 6px 8px;
                    text-align: center;
                }
                table.data-table th {
                    background-color: #e2e8f0;
                    color: #0f172a;
                    font-weight: bold;
                    font-size: 12px;
                }
                table.data-table td.name {
                    text-align: right;
                    font-weight: 600;
                    padding-right: 10px;
                }
                table.data-table td.num {
                    width: 32px;
                    background: #f8fafc;
                }
                table.data-table td.mat {
                    width: 90px;
                    font-family: monospace;
                    direction: ltr;
                }
                table.data-table td.birth {
                    width: 85px;
                }
                table.data-table td.status {
                    width: 70px;
                }
                table.data-table td.obs {
                    width: 90px;
                }
                .footer {
                    margin-top: 25px;
                    width: 100%;
                }
                .signature-box {
                    width: 45%;
                    display: inline-block;
                    text-align: center;
                    vertical-align: top;
                    font-weight: bold;
                    border: 1px dashed #94a3b8;
                    padding: 10px;
                    border-radius: 6px;
                    min-height: 70px;
                }
            </style>
        </head>
        <body>
            <div class="republic">الجمهورية الجزائرية الديمقراطية الشعبية</div>
            <div class="ministry">وزارة التربية الوطنية</div>

            <table class="header-table">
                <tr>
                    <td style="width: 50%;">
                        <strong>المؤسسة:</strong> ${profile.schoolName.ifBlank { "متوسطة الأمير عبد القادر" }}<br>
                        <strong>الأستاذ(ة):</strong> ${profile.teacher.ifBlank { "الأستاذ" }}<br>
                        <strong>المادة:</strong> ${profile.subject.ifBlank { "الرياضيات" }}
                    </td>
                    <td style="width: 50%; text-align: left;">
                        <strong>السنة الدراسية:</strong> ${section.year}<br>
                        <strong>المستوى:</strong> ${section.level}<br>
                        <strong>الحجرة:</strong> ${section.roomNumber}
                    </td>
                </tr>
            </table>

            <div class="title-box">
                قائمة الفوج التربوي: قسم ${section.name} (${section.level})
            </div>

            <table class="meta-table">
                <tr>
                    <td><strong>تعداد القسم:</strong> ${students.size} تلميذاً</td>
                    <td><strong>تاريخ الطباعة:</strong> ${java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.getDefault()).format(java.util.Date())}</td>
                    <td><strong>النظام:</strong> الرقمنة والتقويم المستمر</td>
                </tr>
            </table>

            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 35px;">ر.ت</th>
                        <th style="width: 100px;">رقم التعريف المدرسي</th>
                        <th>اللقب والاسم</th>
                        <th style="width: 95px;">تاريخ الميلاد</th>
                        <th style="width: 75px;">الصفة</th>
                        <th style="width: 110px;">الملاحظات / المتابعة</th>
                    </tr>
                </thead>
                <tbody>
                    $rowsHtml
                </tbody>
            </table>

            <table class="footer">
                <tr>
                    <td style="width: 50%; text-align: center;">
                        <div class="signature-box">
                            إمضاء وختم الأستاذ(ة)
                        </div>
                    </td>
                    <td style="width: 50%; text-align: center;">
                        <div class="signature-box">
                            ختم وتأشيرة إدارة المؤسسة
                        </div>
                    </td>
                </tr>
            </table>
        </body>
        </html>
        """.trimIndent()
    }

    private fun buildGradebookHtml(
        section: Section,
        profile: TeacherProfile,
        rows: List<GradebookRow>
    ): String {
        val rowsHtml = StringBuilder()
        var totalAvg = 0.0
        var count = 0

        rows.forEachIndexed { index, r ->
            val total = r.activityScore + r.homeworkScore + (r.examScore * 2)
            val avg = total / 4.0
            totalAvg += avg
            count++

            rowsHtml.append(
                """
                <tr>
                    <td class="num">${index + 1}</td>
                    <td class="mat">${r.matricule}</td>
                    <td class="name">${r.nom} ${r.prenom}</td>
                    <td>${"%.2f".format(r.activityScore)}</td>
                    <td>${"%.2f".format(r.homeworkScore)}</td>
                    <td>${"%.2f".format(r.examScore)}</td>
                    <td class="avg"><strong>${"%.2f".format(avg)}</strong></td>
                    <td>${r.observation.ifBlank { if (avg >= 10.0) "يستحسن" else "يحتاج جهداً" }}</td>
                </tr>
                """.trimIndent()
            )
        }

        val classAvg = if (count > 0) totalAvg / count else 0.0

        return """
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
            <meta charset="utf-8">
            <title>دفتر تنقيط قسم ${section.name}</title>
            <style>
                @page { size: A4 landscape; margin: 10mm; }
                body {
                    font-family: 'Cairo', 'Amiri', 'Segoe UI', Tahoma, sans-serif;
                    direction: rtl;
                    text-align: right;
                    color: #111827;
                    margin: 0;
                    padding: 8px;
                    background: #fff;
                    font-size: 12px;
                }
                .republic { text-align: center; font-weight: bold; font-size: 14px; margin-bottom: 4px; }
                .title-box {
                    text-align: center;
                    border: 2px solid #0f766e;
                    background-color: #f0fdfa;
                    padding: 6px;
                    border-radius: 6px;
                    font-size: 15px;
                    font-weight: bold;
                    color: #0f766e;
                    margin: 8px auto;
                    width: 70%;
                }
                table.data-table { width: 100%; border-collapse: collapse; margin-top: 8px; }
                table.data-table th, table.data-table td {
                    border: 1px solid #334155;
                    padding: 5px 6px;
                    text-align: center;
                }
                table.data-table th { background-color: #e2e8f0; font-size: 11px; }
                table.data-table td.name { text-align: right; font-weight: 600; padding-right: 8px; }
                table.data-table td.avg { background: #f0fdf4; color: #166534; font-weight: bold; }
            </style>
        </head>
        <body>
            <div class="republic">الجمهورية الجزائرية الديمقراطية الشعبية - وزارة التربية الوطنية</div>
            <div class="title-box">
                كشف نقاط التقويم المستمر والمراقبة الدورية - قسم ${section.name} (${section.level})
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 12px;">
                <div><strong>المؤسسة:</strong> ${profile.schoolName} | <strong>الأستاذ(ة):</strong> ${profile.teacher} | <strong>المادة:</strong> ${profile.subject}</div>
                <div><strong>السنة الدراسية:</strong> ${section.year} | <strong>معدل القسم:</strong> ${"%.2f / 20.0".format(classAvg)}</div>
            </div>

            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 30px;">ر.ت</th>
                        <th style="width: 90px;">رقم التعريف</th>
                        <th>اللقب والاسم</th>
                        <th style="width: 80px;">التقويم المستمر</th>
                        <th style="width: 70px;">الفرض</th>
                        <th style="width: 70px;">الاختبار</th>
                        <th style="width: 75px;">المعدل / 20</th>
                        <th style="width: 100px;">الملاحظة</th>
                    </tr>
                </thead>
                <tbody>
                    $rowsHtml
                </tbody>
            </table>
        </body>
        </html>
        """.trimIndent()
    }

    private fun buildBlankAssessmentGridHtml(
        section: Section,
        profile: TeacherProfile,
        criteria: List<AssessmentCriterion>,
        students: List<Student>
    ): String {
        val thCriteria = StringBuilder()
        criteria.forEach { crit ->
            thCriteria.append("""<th style="min-width: 55px;">${crit.icon} ${crit.name}<br><small style="font-weight: normal; color: #475569;">/ ${crit.max.toInt()}</small></th>""")
        }

        val rowsHtml = StringBuilder()
        students.forEachIndexed { index, s ->
            rowsHtml.append("""
                <tr>
                    <td class="num">${index + 1}</td>
                    <td class="mat">${s.matricule.ifBlank { "—" }}</td>
                    <td class="name">${s.fullName}</td>
            """)
            criteria.forEach { _ ->
                rowsHtml.append("""<td class="blank-cell"></td>""")
            }
            rowsHtml.append("""
                    <td class="blank-cell" style="background: #fafafa;"></td>
                    <td class="obs"></td>
                </tr>
            """.trimIndent())
        }

        return """
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
            <meta charset="utf-8">
            <title>شبكة التقويم المستمر الفارغة - قسم ${section.name}</title>
            <style>
                @page { size: A4 landscape; margin: 8mm; }
                body {
                    font-family: 'Cairo', 'Amiri', 'Segoe UI', Tahoma, sans-serif;
                    direction: rtl;
                    text-align: right;
                    color: #111827;
                    margin: 0;
                    padding: 6px;
                    background: #fff;
                    font-size: 11px;
                }
                .republic { text-align: center; font-weight: bold; font-size: 13px; margin-bottom: 2px; }
                .title-box {
                    text-align: center;
                    border: 2px solid #2563eb;
                    background-color: #eff6ff;
                    padding: 5px;
                    border-radius: 6px;
                    font-size: 14px;
                    font-weight: bold;
                    color: #1e40af;
                    margin: 4px auto;
                    width: 75%;
                }
                .meta-bar {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 6px;
                    font-size: 11px;
                    padding: 4px 8px;
                    background: #f8fafc;
                    border: 1px solid #e2e8f0;
                    border-radius: 4px;
                }
                table.data-table { width: 100%; border-collapse: collapse; margin-top: 4px; }
                table.data-table th, table.data-table td {
                    border: 1px solid #334155;
                    padding: 4px 5px;
                    text-align: center;
                    height: 22px;
                }
                table.data-table th { background-color: #e2e8f0; font-size: 11px; }
                table.data-table td.name { text-align: right; font-weight: 600; padding-right: 8px; }
                table.data-table td.num { width: 28px; background: #f8fafc; }
                table.data-table td.mat { width: 85px; font-family: monospace; direction: ltr; }
                table.data-table td.blank-cell { min-width: 45px; background: #fff; }
                table.data-table td.obs { min-width: 80px; }
                .footer {
                    margin-top: 14px;
                    display: flex;
                    justify-content: space-between;
                }
                .signature {
                    width: 45%;
                    text-align: center;
                    font-weight: bold;
                    border: 1px dashed #cbd5e1;
                    padding: 6px;
                    border-radius: 4px;
                    font-size: 11px;
                }
            </style>
        </head>
        <body>
            <div class="republic">الجمهورية الجزائرية الديمقراطية الشعبية - وزارة التربية الوطنية</div>
            <div class="title-box">
                شبكة ملاحظة وتقويم الأنشطة الصفية المستمرة (فارغة للتنقيط اليدوي) - قسم ${section.name} (${section.level})
            </div>
            <div class="meta-bar">
                <div><strong>المؤسسة:</strong> ${profile.schoolName} | <strong>الأستاذ(ة):</strong> ${profile.teacher} | <strong>المادة:</strong> ${profile.subject}</div>
                <div><strong>السنة الدراسية:</strong> ${section.year} | <strong>تعداد القسم:</strong> ${students.size} تلميذاً</div>
            </div>

            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 28px;">ر.ت</th>
                        <th style="width: 85px;">رقم التعريف</th>
                        <th>اللقب والاسم</th>
                        $thCriteria
                        <th style="width: 85px; background: #dbeafe;">مجموع التقويمات / معدل التقويم المستمر<br><small>/ 20.0</small></th>
                        <th style="width: 90px;">الملاحظات والتقدير</th>
                    </tr>
                </thead>
                <tbody>
                    $rowsHtml
                </tbody>
            </table>

            <div class="footer">
                <div class="signature">إمضاء وختم الأستاذ(ة)</div>
                <div class="signature">ختم وتأشيرة إدارة المؤسسة</div>
            </div>
        </body>
        </html>
        """.trimIndent()
    }

    private fun buildBlankGradebookHtml(
        section: Section,
        profile: TeacherProfile,
        students: List<Student>
    ): String {
        val rowsHtml = StringBuilder()
        students.forEachIndexed { index, s ->
            rowsHtml.append("""
                <tr>
                    <td class="num">${index + 1}</td>
                    <td class="mat">${s.matricule.ifBlank { "—" }}</td>
                    <td class="name">${s.fullName}</td>
                    <td class="blank"></td>
                    <td class="blank"></td>
                    <td class="blank"></td>
                    <td class="blank" style="background: #fafafa;"></td>
                    <td class="obs"></td>
                </tr>
            """.trimIndent())
        }

        return """
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
            <meta charset="utf-8">
            <title>دفتر تنقيط فارغ - قسم ${section.name}</title>
            <style>
                @page { size: A4 landscape; margin: 8mm; }
                body {
                    font-family: 'Cairo', 'Amiri', 'Segoe UI', Tahoma, sans-serif;
                    direction: rtl;
                    text-align: right;
                    color: #111827;
                    margin: 0;
                    padding: 6px;
                    background: #fff;
                    font-size: 11px;
                }
                .republic { text-align: center; font-weight: bold; font-size: 13px; margin-bottom: 2px; }
                .title-box {
                    text-align: center;
                    border: 2px solid #0f766e;
                    background-color: #f0fdfa;
                    padding: 5px;
                    border-radius: 6px;
                    font-size: 14px;
                    font-weight: bold;
                    color: #0f766e;
                    margin: 4px auto;
                    width: 75%;
                }
                .meta-bar {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 6px;
                    font-size: 11px;
                    padding: 4px 8px;
                    background: #f8fafc;
                    border: 1px solid #e2e8f0;
                    border-radius: 4px;
                }
                table.data-table { width: 100%; border-collapse: collapse; margin-top: 4px; }
                table.data-table th, table.data-table td {
                    border: 1px solid #334155;
                    padding: 4px 5px;
                    text-align: center;
                    height: 22px;
                }
                table.data-table th { background-color: #e2e8f0; font-size: 11px; }
                table.data-table td.name { text-align: right; font-weight: 600; padding-right: 8px; }
                table.data-table td.num { width: 28px; background: #f8fafc; }
                table.data-table td.mat { width: 90px; font-family: monospace; direction: ltr; }
                table.data-table td.blank { width: 75px; background: #fff; }
                table.data-table td.obs { width: 100px; }
                .footer {
                    margin-top: 14px;
                    display: flex;
                    justify-content: space-between;
                }
                .signature {
                    width: 45%;
                    text-align: center;
                    font-weight: bold;
                    border: 1px dashed #cbd5e1;
                    padding: 6px;
                    border-radius: 4px;
                    font-size: 11px;
                }
            </style>
        </head>
        <body>
            <div class="republic">الجمهورية الجزائرية الديمقراطية الشعبية - وزارة التربية الوطنية</div>
            <div class="title-box">
                كشف حجز نقاط المراقبة المستمرة والتقويم التربوي (فارغ للتنقيط اليدوي) - قسم ${section.name} (${section.level})
            </div>
            <div class="meta-bar">
                <div><strong>المؤسسة:</strong> ${profile.schoolName} | <strong>الأستاذ(ة):</strong> ${profile.teacher} | <strong>المادة:</strong> ${profile.subject}</div>
                <div><strong>السنة الدراسية:</strong> ${section.year} | <strong>تعداد القسم:</strong> ${students.size} تلميذاً</div>
            </div>

            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 28px;">ر.ت</th>
                        <th style="width: 90px;">رقم التعريف</th>
                        <th>اللقب والاسم</th>
                        <th style="width: 80px;">التقويم المستمر<br><small>/ 20</small></th>
                        <th style="width: 75px;">الفرض<br><small>/ 20</small></th>
                        <th style="width: 75px;">الاختبار<br><small>/ 20</small></th>
                        <th style="width: 80px; background: #ccfbf1;">المعدل<br><small>/ 20</small></th>
                        <th style="width: 100px;">الملاحظات والتقدير</th>
                    </tr>
                </thead>
                <tbody>
                    $rowsHtml
                </tbody>
            </table>

            <div class="footer">
                <div class="signature">إمضاء وختم الأستاذ(ة)</div>
                <div class="signature">ختم وتأشيرة إدارة المؤسسة</div>
            </div>
        </body>
        </html>
        """.trimIndent()
    }
}
