package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.GradebookRow
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedReader
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class ParsedStudent(
    val fullName: String,
    val matricule: String = "",
    val birthDate: String = "",
    val sectionName: String = ""
)

object ExcelHelper {

    fun parseStream(inputStream: InputStream): List<ParsedStudent> {
        val bytes = inputStream.readBytes()
        if (bytes.size < 4) return emptyList()

        // Check if ZIP / XLSX (Magic bytes: 0x50, 0x4B, 0x03, 0x04)
        val isZip = bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()
        return if (isZip) {
            parseXlsxBytes(bytes)
        } else {
            parseCsvOrTextBytes(bytes)
        }
    }

    private fun parseXlsxBytes(bytes: ByteArray): List<ParsedStudent> {
        val sharedStrings = mutableListOf<String>()
        val rows = mutableListOf<List<String>>()

        // Pass 1: Extract sharedStrings.xml
        try {
            val zis = ZipInputStream(ByteArrayInputStream(bytes))
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                if (entry.name.equals("xl/sharedStrings.xml", ignoreCase = true)) {
                    val factory = XmlPullParserFactory.newInstance()
                    factory.isNamespaceAware = true
                    val parser = factory.newPullParser()
                    parser.setInput(zis, "UTF-8")

                    var eventType = parser.eventType
                    var inText = false
                    val currentText = StringBuilder()

                    while (eventType != XmlPullParser.END_DOCUMENT) {
                        val name = parser.name
                        when (eventType) {
                            XmlPullParser.START_TAG -> {
                                if (name == "t") inText = true
                            }
                            XmlPullParser.TEXT -> {
                                if (inText) currentText.append(parser.text)
                            }
                            XmlPullParser.END_TAG -> {
                                if (name == "t") inText = false
                                else if (name == "si") {
                                    sharedStrings.add(currentText.toString())
                                    currentText.setLength(0)
                                }
                            }
                        }
                        eventType = parser.next()
                    }
                    break
                }
                entry = zis.nextEntry
            }
            zis.close()
        } catch (_: Exception) {}

        // Pass 2: Extract sheet1.xml
        try {
            val zis = ZipInputStream(ByteArrayInputStream(bytes))
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                if (entry.name.matches(Regex("xl/worksheets/sheet[0-9]+\\.xml", RegexOption.IGNORE_CASE))) {
                    val factory = XmlPullParserFactory.newInstance()
                    factory.isNamespaceAware = true
                    val parser = factory.newPullParser()
                    parser.setInput(zis, "UTF-8")

                    var eventType = parser.eventType
                    var currentRow = mutableListOf<String>()
                    var cellType = ""
                    var inVal = false
                    var inText = false
                    val cellVal = StringBuilder()

                    while (eventType != XmlPullParser.END_DOCUMENT) {
                        val name = parser.name
                        when (eventType) {
                            XmlPullParser.START_TAG -> {
                                when (name) {
                                    "row" -> currentRow = mutableListOf()
                                    "c" -> {
                                        cellType = parser.getAttributeValue(null, "t") ?: ""
                                        cellVal.setLength(0)
                                    }
                                    "v" -> inVal = true
                                    "t" -> inText = true
                                }
                            }
                            XmlPullParser.TEXT -> {
                                if (inVal || inText) cellVal.append(parser.text)
                            }
                            XmlPullParser.END_TAG -> {
                                when (name) {
                                    "v" -> inVal = false
                                    "t" -> inText = false
                                    "c" -> {
                                        val raw = cellVal.toString().trim()
                                        val resolved = when (cellType) {
                                            "s" -> {
                                                val sIdx = raw.toIntOrNull()
                                                if (sIdx != null && sIdx in sharedStrings.indices) sharedStrings[sIdx] else raw
                                            }
                                            else -> raw
                                        }
                                        currentRow.add(resolved)
                                    }
                                    "row" -> {
                                        if (currentRow.any { it.isNotBlank() }) {
                                            rows.add(currentRow)
                                        }
                                    }
                                }
                            }
                        }
                        eventType = parser.next()
                    }
                    break
                }
                entry = zis.nextEntry
            }
            zis.close()
        } catch (_: Exception) {}

        return mapTableRowsToStudents(rows)
    }

    private fun parseCsvOrTextBytes(bytes: ByteArray): List<ParsedStudent> {
        val lines = try {
            BufferedReader(InputStreamReader(ByteArrayInputStream(bytes), StandardCharsets.UTF_8)).readLines()
        } catch (_: Exception) {
            BufferedReader(InputStreamReader(ByteArrayInputStream(bytes))).readLines()
        }

        val rows = lines.mapNotNull { line ->
            val clean = line.trim()
            if (clean.isBlank()) return@mapNotNull null
            // Check separator: comma, semicolon, or tab
            val sep = when {
                clean.contains(";") -> ";"
                clean.contains("\t") -> "\t"
                clean.contains(",") -> ","
                else -> null
            }
            if (sep != null) clean.split(sep).map { it.trim().trim('"', '\'') }
            else listOf(clean)
        }

        return mapTableRowsToStudents(rows)
    }

    fun parsePastedText(text: String): List<ParsedStudent> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val rows = lines.map { line ->
            // remove leading bullet or numbers like "1.", "1 -", "•"
            val sanitized = line.replace(Regex("^[0-9]+[.\\-)\\s]+"), "").replace(Regex("^[•*\\-]+\\s*"), "").trim()
            if (sanitized.contains("\t")) sanitized.split("\t")
            else if (sanitized.contains(";")) sanitized.split(";")
            else if (sanitized.contains(",")) sanitized.split(",")
            else listOf(sanitized)
        }
        return mapTableRowsToStudents(rows)
    }

    private fun mapTableRowsToStudents(rows: List<List<String>>): List<ParsedStudent> {
        if (rows.isEmpty()) return emptyList()

        // Detect if row 0 is header
        val header = rows.first()
        var matriculeCol = -1
        var nomCol = -1
        var prenomCol = -1
        var fullNameCol = -1
        var birthDateCol = -1
        var sectionCol = -1

        header.forEachIndexed { idx, colText ->
            val c = colText.trim().lowercase()
            when {
                c.contains("تعريف") || c.contains("تسجيل") || c.contains("matricule") || c.contains("رقم") -> matriculeCol = idx
                c.contains("الاسم واللقب") || c.contains("اللقب والاسم") || c.contains("اسم التلميذ") || c.contains("الاسم الكامل") || c.contains("nom et prénom") -> fullNameCol = idx
                c == "اللقب" || c == "nom" -> nomCol = idx
                c == "الاسم" || c == "prenom" || c == "prénom" -> prenomCol = idx
                c.contains("ميلاد") || c.contains("ازدياد") || c.contains("naissance") || c.contains("date") -> birthDateCol = idx
                c.contains("قسم") || c.contains("فوج") || c.contains("classe") || c.contains("groupe") -> sectionCol = idx
            }
        }

        val hasHeader = (matriculeCol >= 0 || nomCol >= 0 || fullNameCol >= 0 || sectionCol >= 0)
        val dataRows = if (hasHeader) rows.drop(1) else rows

        val result = mutableListOf<ParsedStudent>()
        dataRows.forEachIndexed { rIdx, row ->
            if (row.isEmpty()) return@forEachIndexed

            val matricule = if (matriculeCol in row.indices) row[matriculeCol] else ""
            val birthDate = if (birthDateCol in row.indices) row[birthDateCol] else "15/05/2012"
            val secName = if (sectionCol in row.indices) row[sectionCol] else ""

            val name = when {
                fullNameCol in row.indices && row[fullNameCol].isNotBlank() -> row[fullNameCol]
                nomCol in row.indices && prenomCol in row.indices -> "${row[nomCol]} ${row[prenomCol]}".trim()
                nomCol in row.indices && row[nomCol].isNotBlank() -> row[nomCol]
                prenomCol in row.indices && row[prenomCol].isNotBlank() -> row[prenomCol]
                else -> {
                    // Fallback to first non-empty column that isn't purely digits
                    val textCol = row.firstOrNull { it.isNotBlank() && it.any { ch -> ch.isLetter() } }
                    textCol ?: row.firstOrNull() ?: ""
                }
            }

            val cleanName = name.trim().trim('"', '\'')
            if (cleanName.isNotBlank() && !cleanName.contains("اسم التلميذ") && !cleanName.contains("اللقب والاسم")) {
                result.add(
                    ParsedStudent(
                        fullName = cleanName,
                        matricule = matricule.ifBlank { "26%04d".format(rIdx + 1) },
                        birthDate = birthDate.ifBlank { "15/05/2012" },
                        sectionName = secName
                    )
                )
            }
        }
        return result
    }

    fun createSectionTemplateXlsx(): ByteArray {
        val headers = listOf("رقم التعريف", "اللقب", "الاسم", "تاريخ الميلاد", "القسم")
        val sampleRows = listOf(
            listOf("2601001", "بن علي", "أحمد", "15/04/2012", "1م1"),
            listOf("2601002", "بوجمعة", "فاطمة الزهراء", "22/08/2012", "1م1"),
            listOf("2601003", "بلقاسم", "محمد الأمين", "03/11/2012", "1م1"),
            listOf("2601004", "منصوري", "خديجة", "18/01/2012", "1م1"),
            listOf("2601005", "براهيمي", "يوسف", "09/06/2012", "1م1")
        )
        return createXlsxWorkbook("قالب التلاميذ", headers, sampleRows)
    }

    fun createGradebookXlsx(sectionName: String, schoolYear: String, rows: List<GradebookRow>): ByteArray {
        val headers = listOf("م", "رقم التعريف", "اللقب", "الاسم", "تاريخ الميلاد", "تقويم النشاطات /20", "الفرض /20", "الاختبار /20", "المعدل", "التقدير")
        val data = rows.mapIndexed { i, r ->
            listOf(
                (i + 1).toString(),
                r.matricule,
                r.nom,
                r.prenom,
                r.dateNaissance,
                "%.1f".format(r.activityScore),
                "%.1f".format(r.homeworkScore),
                "%.1f".format(r.examScore),
                "%.2f".format(r.calculatedAverage),
                r.autoObservation
            )
        }
        return createXlsxWorkbook("دفتر تنقيط $sectionName", headers, data)
    }

    fun createStudentsListXlsx(sectionName: String, students: List<ParsedStudent>): ByteArray {
        val headers = listOf("م", "رقم التعريف", "اسم التلميذ الكامل", "تاريخ الميلاد", "القسم")
        val data = students.mapIndexed { idx, s ->
            listOf((idx + 1).toString(), s.matricule, s.fullName, s.birthDate, sectionName)
        }
        return createXlsxWorkbook("تلاميذ $sectionName", headers, data)
    }

    private fun createXlsxWorkbook(sheetName: String, headers: List<String>, rows: List<List<String>>): ByteArray {
        val bos = ByteArrayOutputStream()
        val zos = ZipOutputStream(bos)

        // 1. [Content_Types].xml
        zos.putNextEntry(ZipEntry("[Content_Types].xml"))
        zos.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>""".toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        // 2. _rels/.rels
        zos.putNextEntry(ZipEntry("_rels/.rels"))
        zos.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""".toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        // 3. xl/_rels/workbook.xml.rels
        zos.putNextEntry(ZipEntry("xl/_rels/workbook.xml.rels"))
        zos.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>""".toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        // 4. xl/workbook.xml
        val safeSheetName = sheetName.replace(Regex("[:\\\\/?*\\[\\]]"), " ")
        zos.putNextEntry(ZipEntry("xl/workbook.xml"))
        zos.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="$safeSheetName" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>""".toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        // 5. xl/worksheets/sheet1.xml
        val sheetBuilder = StringBuilder()
        sheetBuilder.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetViews><sheetView tabSelected="1" workbookViewId="0" rightToLeft="1"/></sheetViews>
  <sheetData>
""")

        // Row 1: Header
        sheetBuilder.append("    <row r=\"1\">\n")
        headers.forEachIndexed { cIdx, hText ->
            val colLetter = getColumnLetter(cIdx)
            sheetBuilder.append("      <c r=\"$colLetter${1}\" t=\"inlineStr\"><is><t>${escapeXml(hText)}</t></is></c>\n")
        }
        sheetBuilder.append("    </row>\n")

        // Rows 2..N
        rows.forEachIndexed { rIdx, row ->
            val rowNum = rIdx + 2
            sheetBuilder.append("    <row r=\"$rowNum\">\n")
            row.forEachIndexed { cIdx, cellText ->
                val colLetter = getColumnLetter(cIdx)
                sheetBuilder.append("      <c r=\"$colLetter$rowNum\" t=\"inlineStr\"><is><t>${escapeXml(cellText)}</t></is></c>\n")
            }
            sheetBuilder.append("    </row>\n")
        }

        sheetBuilder.append("""  </sheetData>
</worksheet>""")

        zos.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
        zos.write(sheetBuilder.toString().toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        zos.finish()
        zos.flush()
        return bos.toByteArray()
    }

    private fun getColumnLetter(colIndex: Int): String {
        var temp = colIndex
        val letter = StringBuilder()
        while (temp >= 0) {
            letter.insert(0, ('A'.code + (temp % 26)).toChar())
            temp = (temp / 26) - 1
        }
        return letter.toString()
    }

    private fun escapeXml(text: String): String {
        return text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    fun shareFile(context: Context, fileName: String, data: ByteArray, title: String = "مشاركة الملف") {
        try {
            val file = File(context.cacheDir, fileName)
            file.writeBytes(data)

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, fileName)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
