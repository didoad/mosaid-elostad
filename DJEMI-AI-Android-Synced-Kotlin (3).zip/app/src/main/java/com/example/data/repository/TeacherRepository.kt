package com.example.data.repository

import android.content.Context
import com.example.data.model.AssessmentCriterion
import com.example.data.model.AttendanceStatus
import com.example.data.model.GradebookRow
import com.example.data.model.LevelInfo
import com.example.data.model.Section
import com.example.data.model.Student
import com.example.data.model.TeacherProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class TeacherRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("djemi_ai_prefs", Context.MODE_PRIVATE)
    private val sectionKeyAliases = mutableMapOf<Long, String>()

    private fun parseFlexibleId(raw: Any?): Long {
        return when (raw) {
            is Number -> raw.toLong()
            is String -> {
                val digits = raw.filter { it.isDigit() }
                digits.toLongOrNull() ?: (raw.hashCode().toLong() and 0x7FFFFFFFL).coerceAtLeast(1L)
            }
            else -> 1L
        }
    }

    private fun exportSectionKey(secId: Long): String {
        return sectionKeyAliases[secId] ?: "sec_$secId"
    }

    val allLevels = listOf(
        LevelInfo(code = "1AM", label = "الأولى متوسط"),
        LevelInfo(code = "2AM", label = "الثانية متوسط"),
        LevelInfo(code = "3AM", label = "الثالثة متوسط"),
        LevelInfo(code = "4AM", label = "الرابعة متوسط")
    )

    val defaultCriteriaList = listOf(
        AssessmentCriterion(id = 1, name = "الحضور والمواظبة", max = 2.0, score = 1.0, icon = "⏱", colorHex = "#5349D8"),
        AssessmentCriterion(id = 2, name = "السلوك", max = 2.0, score = 1.0, icon = "⭐", colorHex = "#EA580C"),
        AssessmentCriterion(id = 3, name = "إحضار الأدوات المدرسية", max = 2.0, score = 1.0, icon = "📐", colorHex = "#2563EB"),
        AssessmentCriterion(id = 4, name = "تنظيم الكراس", max = 2.0, score = 1.0, icon = "📓", colorHex = "#0284C7"),
        AssessmentCriterion(id = 5, name = "المشاركة الفعالة", max = 2.0, score = 1.0, icon = "✋", colorHex = "#16A34A"),
        AssessmentCriterion(id = 6, name = "الاستجواب الشفوي", max = 2.0, score = 1.0, icon = "🗣️", colorHex = "#0D9488"),
        AssessmentCriterion(id = 7, name = "الاستجواب الكتابي", max = 2.0, score = 1.0, icon = "📝", colorHex = "#7C3AED"),
        AssessmentCriterion(id = 8, name = "الواجبات المنزلية", max = 2.0, score = 1.0, icon = "📚", colorHex = "#059669"),
        AssessmentCriterion(id = 9, name = "المشاريع والبحوث", max = 2.0, score = 1.0, icon = "🔬", colorHex = "#D97706"),
        AssessmentCriterion(id = 10, name = "المبادرة والمساهمة", max = 2.0, score = 1.0, icon = "💡", colorHex = "#E11D48")
    )

    private val _criteria = MutableStateFlow<List<AssessmentCriterion>>(defaultCriteriaList)
    val criteria: StateFlow<List<AssessmentCriterion>> = _criteria.asStateFlow()

    private val _stepSize = MutableStateFlow(0.5)
    val stepSize: StateFlow<Double> = _stepSize.asStateFlow()

    private val _teacherProfile = MutableStateFlow(TeacherProfile())
    val teacherProfile: StateFlow<TeacherProfile> = _teacherProfile.asStateFlow()

    private val _sections = MutableStateFlow<List<Section>>(emptyList())
    val sections: StateFlow<List<Section>> = _sections.asStateFlow()

    private val _selectedSectionId = MutableStateFlow<Long>(1L)
    val selectedSectionId: StateFlow<Long> = _selectedSectionId.asStateFlow()

    private val _studentsBySection = MutableStateFlow<Map<Long, List<Student>>>(emptyMap())
    val studentsBySection: StateFlow<Map<Long, List<Student>>> = _studentsBySection.asStateFlow()

    private val _seatOrderBySection = MutableStateFlow<Map<Long, List<String>>>(emptyMap())
    val seatOrderBySection: StateFlow<Map<Long, List<String>>> = _seatOrderBySection.asStateFlow()

    private val _attendanceBySection = MutableStateFlow<Map<Long, Map<String, AttendanceStatus>>>(emptyMap())
    val attendanceBySection: StateFlow<Map<Long, Map<String, AttendanceStatus>>> = _attendanceBySection.asStateFlow()

    private val _studentScoresBySection = MutableStateFlow<Map<Long, Map<String, List<Double>>>>(emptyMap())
    val studentScoresBySection: StateFlow<Map<Long, Map<String, List<Double>>>> = _studentScoresBySection.asStateFlow()

    private val _gradebookBySection = MutableStateFlow<Map<Long, List<GradebookRow>>>(emptyMap())
    val gradebookBySection: StateFlow<Map<Long, List<GradebookRow>>> = _gradebookBySection.asStateFlow()

    private val _accentColor = MutableStateFlow(0xFF5349D8)
    val accentColor: StateFlow<Long> = _accentColor.asStateFlow()

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        val saved = prefs.getString("data_initialized", null)
        if (saved == null) {
            val bundledJson = try {
                context.assets.open("initial_settings_bundle.json").bufferedReader().use { it.readText() }
            } catch (_: Exception) {
                null
            }
            if (!bundledJson.isNullOrBlank() && applySerializedState(bundledJson, suppressCloudNotify = true)) {
                return
            }
            seedInitialData()
        } else {
            try {
                restoreFromPrefs()
            } catch (e: Exception) {
                seedInitialData()
            }
        }
    }

    private fun seedInitialData() {
        _teacherProfile.value = TeacherProfile(
            schoolName = "متوسطة الأمير عبد القادر",
            teacher = "الأستاذ دجمي زازوي",
            year = "2026 / 2027",
            subject = "مادة الرياضيات"
        )

        val initSections = listOf(
            Section(id = 1L, name = "1م1", code = "1AM-1", level = "الأولى متوسط", year = "2026 / 2027", subject = "الرياضيات", roomNumber = "04", rows = 4, cols = 3, deskSide = "right"),
            Section(id = 2L, name = "1م2", code = "1AM-2", level = "الأولى متوسط", year = "2026 / 2027", subject = "الرياضيات", roomNumber = "04", rows = 4, cols = 3, deskSide = "right"),
            Section(id = 3L, name = "2م1", code = "2AM-1", level = "الثانية متوسط", year = "2026 / 2027", subject = "الرياضيات", roomNumber = "07", rows = 4, cols = 3, deskSide = "left"),
            Section(id = 4L, name = "3م2", code = "3AM-2", level = "الثالثة متوسط", year = "2026 / 2027", subject = "الرياضيات", roomNumber = "12", rows = 4, cols = 3, deskSide = "right"),
            Section(id = 5L, name = "4م1", code = "4AM-1", level = "الرابعة متوسط", year = "2026 / 2027", subject = "الرياضيات", roomNumber = "15", rows = 4, cols = 3, deskSide = "right")
        )
        _sections.value = initSections
        _selectedSectionId.value = 1L

        val defaultNames = listOf(
            "أحمد بن علي",
            "فاطمة الزهراء بوجمعة",
            "محمد الأمين بلقاسم",
            "خديجة منصوري",
            "يوسف براهيمي",
            "مريم بلحاج",
            "عبد الرحمن دراجي",
            "إيمان بن حميدة",
            "زكرياء حداد",
            "آية بن يوسف",
            "وليد قاسمي",
            "سارة شريف",
            "حمزة عماري",
            "سندس زروقي",
            "أيوب حركات",
            "نسرين طاهري",
            "ياسين سلطاني",
            "أميرة بوسماحة",
            "بلال رحماني",
            "ريان كباش"
        )

        val sMap = mutableMapOf<Long, List<Student>>()
        val seatMap = mutableMapOf<Long, List<String>>()
        val scoreMap = mutableMapOf<Long, Map<String, List<Double>>>()
        val gbMap = mutableMapOf<Long, List<GradebookRow>>()

        initSections.forEach { sec ->
            val list = defaultNames.mapIndexed { idx, name ->
                Student(
                    id = (sec.id * 100) + idx + 1,
                    sectionId = sec.id,
                    fullName = name,
                    matricule = "26${sec.id}%03d".format(idx + 1),
                    birthDate = "15/05/2012",
                    status = "منتظم"
                )
            }
            sMap[sec.id] = list

            // Seating desks: 4 rows * 3 cols * 2 = 24 seats
            val totalSeats = sec.rows * sec.cols * 2
            val seats = MutableList(totalSeats) { "" }
            defaultNames.forEachIndexed { idx, name ->
                if (idx < totalSeats) seats[idx] = name
            }
            seatMap[sec.id] = seats

            // Student scores: 4 criteria defaults
            val scores = mutableMapOf<String, List<Double>>()
            defaultNames.forEach { name ->
                scores[name] = _criteria.value.map { it.score }
            }
            scoreMap[sec.id] = scores

            // Gradebook rows
            val gRows = list.mapIndexed { i, st ->
                val parts = st.fullName.split(" ")
                val nom = if (parts.size > 1) parts.take(parts.size - 1).joinToString(" ") else parts.first()
                val prenom = parts.last()
                GradebookRow(
                    id = st.id,
                    studentId = st.id,
                    matricule = st.matricule,
                    nom = nom,
                    prenom = prenom,
                    dateNaissance = st.birthDate,
                    activityScore = 10.0,
                    homeworkScore = 15.5,
                    examScore = 16.0,
                    observation = "جيد جداً"
                )
            }
            gbMap[sec.id] = gRows
        }

        _studentsBySection.value = sMap
        _seatOrderBySection.value = seatMap
        _studentScoresBySection.value = scoreMap
        _gradebookBySection.value = gbMap

        saveToPrefs()
    }

    private var onDataChangedListener: (() -> Unit)? = null

    fun setOnDataChangedListener(listener: (() -> Unit)?) {
        onDataChangedListener = listener
    }

    private fun saveToPrefs(suppressCloudNotify: Boolean = false) {
        val fullJson = try { exportFullSerializedState() } catch (_: Exception) { null }
        prefs.edit().apply {
            putString("data_initialized", "true")
            if (fullJson != null) putString("full_state_json", fullJson)
            putLong("accent_color", _accentColor.value)
            putBoolean("is_dark_mode", _isDarkMode.value)
            putFloat("step_size", _stepSize.value.toFloat())

            val p = _teacherProfile.value
            putString("teacher_school", p.schoolName)
            putString("teacher_name", p.teacher)
            putString("teacher_year", p.year)
            putString("teacher_subject", p.subject)

            val critJson = JSONArray()
            _criteria.value.forEach { c ->
                val obj = JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("max", c.max)
                    put("score", c.score)
                    put("icon", c.icon)
                    put("colorHex", c.colorHex)
                }
                critJson.put(obj)
            }
            putString("saved_criteria", critJson.toString())
            apply()
        }
        if (!suppressCloudNotify) {
            onDataChangedListener?.invoke()
        }
    }

    private fun restoreFromPrefs() {
        val fullStateJson = prefs.getString("full_state_json", null)
        if (!fullStateJson.isNullOrBlank()) {
            if (applySerializedState(fullStateJson, suppressCloudNotify = true)) {
                return
            }
        }
        _accentColor.value = prefs.getLong("accent_color", 0xFF5349D8)
        _isDarkMode.value = prefs.getBoolean("is_dark_mode", false)
        val step = prefs.getFloat("step_size", 0.5f).toDouble()
        _stepSize.value = if (step == 0.25 || step == 0.5) step else 0.5

        _teacherProfile.value = TeacherProfile(
            schoolName = prefs.getString("teacher_school", "متوسطة الأمير عبد القادر") ?: "متوسطة الأمير عبد القادر",
            teacher = prefs.getString("teacher_name", "الأستاذ دجمي زازوي") ?: "الأستاذ دجمي زازوي",
            year = prefs.getString("teacher_year", "2026 / 2027") ?: "2026 / 2027",
            subject = prefs.getString("teacher_subject", "مادة الرياضيات") ?: "مادة الرياضيات"
        )

        val critStr = prefs.getString("saved_criteria", null)
        if (!critStr.isNullOrBlank()) {
            try {
                val arr = JSONArray(critStr)
                val list = mutableListOf<AssessmentCriterion>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(
                        AssessmentCriterion(
                            id = obj.optInt("id", i),
                            name = obj.getString("name"),
                            max = obj.getDouble("max"),
                            score = obj.optDouble("score", 0.0),
                            icon = obj.optString("icon", "★"),
                            colorHex = obj.optString("colorHex", "#5349D8")
                        )
                    )
                }
                if (list.isNotEmpty()) {
                    _criteria.value = list
                }
            } catch (_: Exception) {}
        }
        seedInitialData()
    }

    fun setTeacherProfile(profile: TeacherProfile) {
        _teacherProfile.value = profile
        saveToPrefs()
    }

    fun selectSection(id: Long) {
        _selectedSectionId.value = id
    }

    fun setAccentColor(color: Long) {
        _accentColor.value = color
        saveToPrefs()
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
        saveToPrefs()
    }

    fun addSection(name: String, level: String, year: String, initialStudents: List<String>) {
        val newId = (_sections.value.maxOfOrNull { it.id } ?: 0L) + 1L
        val code = when (level) {
            "الأولى متوسط" -> "1AM"
            "الثانية متوسط" -> "2AM"
            "الثالثة متوسط" -> "3AM"
            "الرابعة متوسط" -> "4AM"
            else -> "AM"
        } + "-$newId"

        val newSection = Section(
            id = newId,
            name = name,
            code = code,
            level = level,
            year = year,
            subject = _teacherProfile.value.subject,
            roomNumber = "0%d".format((newId % 10) + 1),
            rows = 4,
            cols = 3,
            deskSide = "right"
        )

        _sections.value = _sections.value + newSection

        val studentsList = initialStudents.mapIndexed { idx, sName ->
            Student(
                id = (newId * 100) + idx + 1,
                sectionId = newId,
                fullName = sName,
                matricule = "26${newId}%03d".format(idx + 1),
                birthDate = "10/05/2012"
            )
        }

        val updatedStudents = _studentsBySection.value.toMutableMap()
        updatedStudents[newId] = studentsList
        _studentsBySection.value = updatedStudents

        val totalSeats = newSection.rows * newSection.cols * 2
        val seats = MutableList(totalSeats) { "" }
        initialStudents.forEachIndexed { i, sName ->
            if (i < totalSeats) seats[i] = sName
        }
        val updatedSeats = _seatOrderBySection.value.toMutableMap()
        updatedSeats[newId] = seats
        _seatOrderBySection.value = updatedSeats

        // Initial scores
        val scores = mutableMapOf<String, List<Double>>()
        initialStudents.forEach { sName ->
            scores[sName] = _criteria.value.map { it.score }
        }
        val updatedScores = _studentScoresBySection.value.toMutableMap()
        updatedScores[newId] = scores
        _studentScoresBySection.value = updatedScores

        // Initial Gradebook
        val gRows = studentsList.map { st ->
            val parts = st.fullName.split(" ")
            val nom = if (parts.size > 1) parts.take(parts.size - 1).joinToString(" ") else parts.first()
            val prenom = parts.last()
            GradebookRow(
                id = st.id,
                studentId = st.id,
                matricule = st.matricule,
                nom = nom,
                prenom = prenom,
                dateNaissance = st.birthDate,
                activityScore = 10.0,
                homeworkScore = 14.0,
                examScore = 15.0,
                observation = "جيد"
            )
        }
        val updatedGb = _gradebookBySection.value.toMutableMap()
        updatedGb[newId] = gRows
        _gradebookBySection.value = updatedGb

        _selectedSectionId.value = newId
        saveToPrefs()
    }

    fun addSectionWithParsedStudents(
        name: String,
        level: String,
        year: String,
        students: List<com.example.util.ParsedStudent>
    ) {
        val newId = (_sections.value.maxOfOrNull { it.id } ?: 0L) + 1L
        val code = when (level) {
            "الأولى متوسط" -> "1AM"
            "الثانية متوسط" -> "2AM"
            "الثالثة متوسط" -> "3AM"
            "الرابعة متوسط" -> "4AM"
            else -> "AM"
        } + "-$newId"

        val newSection = Section(
            id = newId,
            name = name,
            code = code,
            level = level,
            year = year,
            subject = _teacherProfile.value.subject,
            roomNumber = "0%d".format((newId % 10) + 1),
            rows = 4,
            cols = 3,
            deskSide = "right"
        )

        _sections.value = _sections.value + newSection

        val studentsList = students.mapIndexed { idx, s ->
            Student(
                id = (newId * 100) + idx + 1,
                sectionId = newId,
                fullName = s.fullName,
                matricule = s.matricule.ifBlank { "26${newId}%03d".format(idx + 1) },
                birthDate = s.birthDate.ifBlank { "15/05/2012" }
            )
        }

        val updatedStudents = _studentsBySection.value.toMutableMap()
        updatedStudents[newId] = studentsList
        _studentsBySection.value = updatedStudents

        val totalSeats = newSection.rows * newSection.cols * 2
        val seats = MutableList(totalSeats) { "" }
        students.forEachIndexed { i, s ->
            if (i < totalSeats) seats[i] = s.fullName
        }
        val updatedSeats = _seatOrderBySection.value.toMutableMap()
        updatedSeats[newId] = seats
        _seatOrderBySection.value = updatedSeats

        val scores = mutableMapOf<String, List<Double>>()
        students.forEach { s ->
            scores[s.fullName] = _criteria.value.map { it.score }
        }
        val updatedScores = _studentScoresBySection.value.toMutableMap()
        updatedScores[newId] = scores
        _studentScoresBySection.value = updatedScores

        val gRows = studentsList.map { st ->
            val parts = st.fullName.split(" ")
            val nom = if (parts.size > 1) parts.take(parts.size - 1).joinToString(" ") else parts.first()
            val prenom = parts.last()
            GradebookRow(
                id = st.id,
                studentId = st.id,
                matricule = st.matricule,
                nom = nom,
                prenom = prenom,
                dateNaissance = st.birthDate,
                activityScore = 10.0,
                homeworkScore = 14.0,
                examScore = 15.0,
                observation = "جيد"
            )
        }
        val updatedGb = _gradebookBySection.value.toMutableMap()
        updatedGb[newId] = gRows
        _gradebookBySection.value = updatedGb

        _selectedSectionId.value = newId
        saveToPrefs()
    }

    fun importDigitalStudents(parsed: List<com.example.util.ParsedStudent>): Int {
        if (parsed.isEmpty()) return 0
        val hasSections = parsed.any { it.sectionName.isNotBlank() }
        if (hasSections) {
            val grouped = parsed.groupBy { it.sectionName.ifBlank { "قسم مسند" } }
            grouped.forEach { (secName, sList) ->
                val existing = _sections.value.find { it.name.trim() == secName.trim() }
                if (existing != null) {
                    sList.forEach { p ->
                        addStudent(existing.id, p.fullName, p.matricule, p.birthDate)
                    }
                } else {
                    val inferredLevel = when {
                        secName.startsWith("1") -> "الأولى متوسط"
                        secName.startsWith("2") -> "الثانية متوسط"
                        secName.startsWith("3") -> "الثالثة متوسط"
                        secName.startsWith("4") -> "الرابعة متوسط"
                        else -> "الأولى متوسط"
                    }
                    addSectionWithParsedStudents(secName, inferredLevel, _teacherProfile.value.year, sList)
                }
            }
        } else {
            val secId = _selectedSectionId.value
            parsed.forEach { p ->
                addStudent(secId, p.fullName, p.matricule, p.birthDate)
            }
        }
        return parsed.size
    }

    fun addStudent(sectionId: Long, name: String, matricule: String = "", birthDate: String = "") {
        val current = _studentsBySection.value[sectionId] ?: emptyList()
        val newId = (sectionId * 100) + current.size + 1
        val newStudent = Student(
            id = newId,
            sectionId = sectionId,
            fullName = name.trim(),
            matricule = matricule.ifBlank { "26${sectionId}%03d".format(current.size + 1) },
            birthDate = birthDate.ifBlank { "15/05/2012" }
        )
        val updated = _studentsBySection.value.toMutableMap()
        updated[sectionId] = current + newStudent
        _studentsBySection.value = updated

        val seats = (_seatOrderBySection.value[sectionId] ?: emptyList()).toMutableList()
        val emptyIdx = seats.indexOfFirst { it.isEmpty() }
        if (emptyIdx >= 0) {
            seats[emptyIdx] = name.trim()
        } else {
            seats.add(name.trim())
        }
        val updatedSeats = _seatOrderBySection.value.toMutableMap()
        updatedSeats[sectionId] = seats
        _seatOrderBySection.value = updatedSeats

        val scores = (_studentScoresBySection.value[sectionId] ?: emptyMap()).toMutableMap()
        scores[name.trim()] = _criteria.value.map { it.score }
        val updatedScores = _studentScoresBySection.value.toMutableMap()
        updatedScores[sectionId] = scores
        _studentScoresBySection.value = updatedScores

        val parts = name.trim().split(" ")
        val nom = if (parts.size > 1) parts.take(parts.size - 1).joinToString(" ") else parts.first()
        val prenom = parts.last()
        val gb = (_gradebookBySection.value[sectionId] ?: emptyList()) + GradebookRow(
            id = newId,
            studentId = newId,
            matricule = newStudent.matricule,
            nom = nom,
            prenom = prenom,
            dateNaissance = newStudent.birthDate,
            activityScore = 10.0,
            homeworkScore = 15.0,
            examScore = 15.5,
            observation = "جيد"
        )
        val updatedGb = _gradebookBySection.value.toMutableMap()
        updatedGb[sectionId] = gb
        _gradebookBySection.value = updatedGb

        saveToPrefs()
    }

    fun updateSection(section: Section) {
        _sections.value = _sections.value.map { if (it.id == section.id) section else it }
        saveToPrefs()
    }

    fun deleteSection(id: Long) {
        if (_sections.value.size <= 1) return
        _sections.value = _sections.value.filter { it.id != id }
        if (_selectedSectionId.value == id) {
            _selectedSectionId.value = _sections.value.first().id
        }
        saveToPrefs()
    }

    fun addStudent(sectionId: Long, name: String) {
        val current = _studentsBySection.value[sectionId] ?: emptyList()
        val newId = (sectionId * 100) + current.size + 1
        val newStudent = Student(
            id = newId,
            sectionId = sectionId,
            fullName = name.trim(),
            matricule = "26${sectionId}%03d".format(current.size + 1),
            birthDate = "01/01/2012"
        )
        val updated = _studentsBySection.value.toMutableMap()
        updated[sectionId] = current + newStudent
        _studentsBySection.value = updated

        // Put in first empty seat or append
        val seats = (_seatOrderBySection.value[sectionId] ?: emptyList()).toMutableList()
        val emptyIdx = seats.indexOfFirst { it.isEmpty() }
        if (emptyIdx >= 0) {
            seats[emptyIdx] = name.trim()
        } else {
            seats.add(name.trim())
        }
        val updatedSeats = _seatOrderBySection.value.toMutableMap()
        updatedSeats[sectionId] = seats
        _seatOrderBySection.value = updatedSeats

        // Score
        val scores = (_studentScoresBySection.value[sectionId] ?: emptyMap()).toMutableMap()
        scores[name.trim()] = _criteria.value.map { it.score }
        val updatedScores = _studentScoresBySection.value.toMutableMap()
        updatedScores[sectionId] = scores
        _studentScoresBySection.value = updatedScores

        // Gradebook row
        val parts = name.trim().split(" ")
        val nom = if (parts.size > 1) parts.take(parts.size - 1).joinToString(" ") else parts.first()
        val prenom = parts.last()
        val gb = (_gradebookBySection.value[sectionId] ?: emptyList()) + GradebookRow(
            id = newId,
            studentId = newId,
            matricule = newStudent.matricule,
            nom = nom,
            prenom = prenom,
            dateNaissance = newStudent.birthDate,
            activityScore = 10.0,
            homeworkScore = 15.0,
            examScore = 15.5,
            observation = "جيد"
        )
        val updatedGb = _gradebookBySection.value.toMutableMap()
        updatedGb[sectionId] = gb
        _gradebookBySection.value = updatedGb

        saveToPrefs()
    }

    fun renameStudent(sectionId: Long, studentId: Long, newName: String) {
        val current = _studentsBySection.value[sectionId] ?: return
        val oldName = current.find { it.id == studentId }?.fullName ?: return
        val clean = newName.trim()
        if (clean.isBlank()) return

        val updatedStudents = _studentsBySection.value.toMutableMap()
        updatedStudents[sectionId] = current.map {
            if (it.id == studentId) it.copy(fullName = clean) else it
        }
        _studentsBySection.value = updatedStudents

        // Update in seats
        val seats = (_seatOrderBySection.value[sectionId] ?: emptyList()).map {
            if (it == oldName) clean else it
        }
        val updatedSeats = _seatOrderBySection.value.toMutableMap()
        updatedSeats[sectionId] = seats
        _seatOrderBySection.value = updatedSeats

        // Update scores
        val scores = (_studentScoresBySection.value[sectionId] ?: emptyMap()).toMutableMap()
        val oldScore = scores.remove(oldName) ?: _criteria.value.map { it.score }
        scores[clean] = oldScore
        val updatedScores = _studentScoresBySection.value.toMutableMap()
        updatedScores[sectionId] = scores
        _studentScoresBySection.value = updatedScores

        saveToPrefs()
    }

    fun deleteStudent(sectionId: Long, studentId: Long) {
        val current = _studentsBySection.value[sectionId] ?: return
        val target = current.find { it.id == studentId } ?: return

        val updatedStudents = _studentsBySection.value.toMutableMap()
        updatedStudents[sectionId] = current.filter { it.id != studentId }
        _studentsBySection.value = updatedStudents

        // Remove from seats
        val seats = (_seatOrderBySection.value[sectionId] ?: emptyList()).map {
            if (it == target.fullName) "" else it
        }
        val updatedSeats = _seatOrderBySection.value.toMutableMap()
        updatedSeats[sectionId] = seats
        _seatOrderBySection.value = updatedSeats

        // Remove from gradebook
        val gb = (_gradebookBySection.value[sectionId] ?: emptyList()).filter { it.studentId != studentId }
        val updatedGb = _gradebookBySection.value.toMutableMap()
        updatedGb[sectionId] = gb
        _gradebookBySection.value = updatedGb

        saveToPrefs()
    }

    fun clearSectionStudents(sectionId: Long) {
        val updatedStudents = _studentsBySection.value.toMutableMap()
        updatedStudents[sectionId] = emptyList()
        _studentsBySection.value = updatedStudents

        val updatedSeats = _seatOrderBySection.value.toMutableMap()
        val sec = _sections.value.find { it.id == sectionId }
        val totalSeats = (sec?.rows ?: 4) * (sec?.cols ?: 3) * 2
        updatedSeats[sectionId] = List(totalSeats) { "" }
        _seatOrderBySection.value = updatedSeats

        val updatedGb = _gradebookBySection.value.toMutableMap()
        updatedGb[sectionId] = emptyList()
        _gradebookBySection.value = updatedGb

        saveToPrefs()
    }

    fun swapSeats(sectionId: Long, indexA: Int, indexB: Int) {
        val list = (_seatOrderBySection.value[sectionId] ?: emptyList()).toMutableList()
        if (indexA in list.indices && indexB in list.indices) {
            val temp = list[indexA]
            list[indexA] = list[indexB]
            list[indexB] = temp
            val updated = _seatOrderBySection.value.toMutableMap()
            updated[sectionId] = list
            _seatOrderBySection.value = updated
            saveToPrefs()
        }
    }

    fun shuffleSeats(sectionId: Long) {
        val currentStudents = (_studentsBySection.value[sectionId] ?: emptyList()).map { it.fullName }.shuffled()
        val sec = _sections.value.find { it.id == sectionId }
        val totalSeats = (sec?.rows ?: 4) * (sec?.cols ?: 3) * 2
        val newSeats = MutableList(totalSeats) { "" }
        currentStudents.forEachIndexed { i, name ->
            if (i < totalSeats) newSeats[i] = name
        }
        val updated = _seatOrderBySection.value.toMutableMap()
        updated[sectionId] = newSeats
        _seatOrderBySection.value = updated
        saveToPrefs()
    }

    fun updateRoomConfig(sectionId: Long, rows: Int, cols: Int, deskSide: String, roomNumber: String) {
        val sec = _sections.value.find { it.id == sectionId } ?: return
        val updated = sec.copy(
            rows = rows.coerceIn(1, 10),
            cols = cols.coerceIn(2, 6),
            deskSide = deskSide,
            roomNumber = roomNumber.trim().ifBlank { sec.roomNumber }
        )
        updateSection(updated)

        // Adjust seat list size if needed
        val totalSeats = updated.rows * updated.cols * 2
        val currentSeats = (_seatOrderBySection.value[sectionId] ?: emptyList()).filter { it.isNotBlank() }
        val newSeats = MutableList(totalSeats) { "" }
        currentSeats.forEachIndexed { i, name ->
            if (i < totalSeats) newSeats[i] = name
        }
        val updatedSeats = _seatOrderBySection.value.toMutableMap()
        updatedSeats[sectionId] = newSeats
        _seatOrderBySection.value = updatedSeats
        saveToPrefs()
    }

    fun updateDeskScale(sectionId: Long, scale: Int) {
        val sec = _sections.value.find { it.id == sectionId } ?: return
        updateSection(sec.copy(deskScale = scale.coerceIn(65, 150)))
    }

    fun toggleAttendance(sectionId: Long, studentName: String) {
        val sectionAtt = (_attendanceBySection.value[sectionId] ?: emptyMap()).toMutableMap()
        val current = sectionAtt[studentName] ?: AttendanceStatus.PRESENT
        sectionAtt[studentName] = if (current == AttendanceStatus.PRESENT) AttendanceStatus.ABSENT else AttendanceStatus.PRESENT
        val updated = _attendanceBySection.value.toMutableMap()
        updated[sectionId] = sectionAtt
        _attendanceBySection.value = updated
        saveToPrefs()
    }

    fun resetAttendance(sectionId: Long) {
        val updated = _attendanceBySection.value.toMutableMap()
        updated[sectionId] = emptyMap()
        _attendanceBySection.value = updated
        saveToPrefs()
    }

    fun setStepSize(step: Double) {
        _stepSize.value = if (step == 0.25 || step == 0.5) step else 0.5
        saveToPrefs()
    }

    private fun syncAllSectionsContinuousAssessment() {
        _sections.value.forEach { sec ->
            syncContinuousAssessmentToGradebook(sec.id)
        }
    }

    fun addCriterion(name: String, max: Double, icon: String = "★") {
        val current = _criteria.value
        val newId = (current.maxOfOrNull { it.id } ?: 0) + 1
        val colors = listOf("#5349D8", "#0EA5E9", "#10B981", "#F59E0B", "#EC4899", "#8B5CF6")
        val color = colors[newId % colors.size]
        val newCriterion = AssessmentCriterion(
            id = newId,
            name = name.trim(),
            max = max.coerceAtLeast(1.0),
            score = Math.round(max * 0.8 * 10.0) / 10.0,
            icon = icon.ifBlank { "★" },
            colorHex = color
        )
        _criteria.value = current + newCriterion

        // Expand scores for all students
        val secScores = _studentScoresBySection.value.toMutableMap()
        secScores.keys.forEach { secId ->
            val stMap = (secScores[secId] ?: emptyMap()).toMutableMap()
            stMap.keys.forEach { stName ->
                val list = (stMap[stName] ?: emptyList()).toMutableList()
                list.add(Math.round(newCriterion.max * 0.8 * 10.0) / 10.0)
                stMap[stName] = list
            }
            secScores[secId] = stMap
        }
        _studentScoresBySection.value = secScores
        syncAllSectionsContinuousAssessment()
        saveToPrefs()
    }

    fun updateCriterion(id: Int, name: String, max: Double, icon: String) {
        val current = _criteria.value
        val idx = current.indexOfFirst { it.id == id }
        if (idx == -1) return
        val newMax = max.coerceAtLeast(1.0)
        _criteria.value = current.mapIndexed { i, c ->
            if (c.id == id) c.copy(name = name.trim(), max = newMax, icon = icon.ifBlank { c.icon }) else c
        }

        // Clamp student scores to newMax
        val secScores = _studentScoresBySection.value.toMutableMap()
        secScores.keys.forEach { secId ->
            val stMap = (secScores[secId] ?: emptyMap()).toMutableMap()
            stMap.keys.forEach { stName ->
                val list = (stMap[stName] ?: emptyList()).toMutableList()
                if (idx in list.indices) {
                    list[idx] = list[idx].coerceIn(0.0, newMax)
                }
                stMap[stName] = list
            }
            secScores[secId] = stMap
        }
        _studentScoresBySection.value = secScores
        syncAllSectionsContinuousAssessment()
        saveToPrefs()
    }

    fun deleteCriterion(id: Int) {
        val current = _criteria.value
        if (current.size <= 1) return
        val idx = current.indexOfFirst { it.id == id }
        if (idx == -1) return
        _criteria.value = current.filter { it.id != id }

        // Remove from student scores
        val secScores = _studentScoresBySection.value.toMutableMap()
        secScores.keys.forEach { secId ->
            val stMap = (secScores[secId] ?: emptyMap()).toMutableMap()
            stMap.keys.forEach { stName ->
                val list = (stMap[stName] ?: emptyList()).toMutableList()
                if (idx in list.indices) {
                    list.removeAt(idx)
                }
                stMap[stName] = list
            }
            secScores[secId] = stMap
        }
        _studentScoresBySection.value = secScores
        syncAllSectionsContinuousAssessment()
        saveToPrefs()
    }

    fun resetDefaultCriteria() {
        _criteria.value = defaultCriteriaList
        syncAllSectionsContinuousAssessment()
        saveToPrefs()
    }

    fun updateStudentScore(sectionId: Long, studentName: String, criterionIndex: Int, delta: Double) {
        val secScores = (_studentScoresBySection.value[sectionId] ?: emptyMap()).toMutableMap()
        val curList = (secScores[studentName] ?: _criteria.value.map { Math.round(it.max * 0.8 * 10.0) / 10.0 }).toMutableList()
        while (curList.size < _criteria.value.size) {
            val critMax = _criteria.value.getOrNull(curList.size)?.max ?: 5.0
            curList.add(Math.round(critMax * 0.8 * 10.0) / 10.0)
        }
        val maxScore = _criteria.value.getOrNull(criterionIndex)?.max ?: 5.0
        val newScore = ((curList.getOrElse(criterionIndex) { 0.0 }) + delta).coerceIn(0.0, maxScore)
        val rounded = Math.round(newScore * 100.0) / 100.0
        curList[criterionIndex] = rounded
        secScores[studentName] = curList

        val updated = _studentScoresBySection.value.toMutableMap()
        updated[sectionId] = secScores
        _studentScoresBySection.value = updated

        // Immediately auto-sync to Gradebook row in real time
        val totalMax = _criteria.value.sumOf { it.max }.coerceAtLeast(1.0)
        val sum = curList.take(_criteria.value.size).sum()
        val finalScore = if (Math.abs(totalMax - 20.0) < 0.01) sum else (sum / totalMax) * 20.0
        val roundedActivity = Math.round(finalScore.coerceIn(0.0, 20.0) * 100.0) / 100.0

        val currentGb = _gradebookBySection.value[sectionId] ?: emptyList()
        val students = _studentsBySection.value[sectionId] ?: emptyList()
        val matchedStudent = students.find { it.fullName.trim() == studentName.trim() }

        val updatedGb = currentGb.map { row ->
            if (row.studentId == matchedStudent?.id || "${row.nom} ${row.prenom}".trim() == studentName.trim()) {
                row.copy(activityScore = roundedActivity)
            } else {
                row
            }
        }
        val updatedGbMap = _gradebookBySection.value.toMutableMap()
        updatedGbMap[sectionId] = updatedGb
        _gradebookBySection.value = updatedGbMap

        saveToPrefs()
    }

    fun applyBulkScoreToAll(sectionId: Long, criterionIndex: Int, delta: Double) {
        val students = _studentsBySection.value[sectionId] ?: return
        val secScores = (_studentScoresBySection.value[sectionId] ?: emptyMap()).toMutableMap()
        val maxScore = _criteria.value.getOrNull(criterionIndex)?.max ?: 5.0

        students.forEach { st ->
            val curList = (secScores[st.fullName] ?: _criteria.value.map { Math.round(it.max * 0.8 * 10.0) / 10.0 }).toMutableList()
            while (curList.size < _criteria.value.size) {
                val critMax = _criteria.value.getOrNull(curList.size)?.max ?: 5.0
                curList.add(Math.round(critMax * 0.8 * 10.0) / 10.0)
            }
            val newScore = ((curList.getOrElse(criterionIndex) { 0.0 }) + delta).coerceIn(0.0, maxScore)
            val rounded = Math.round(newScore * 100.0) / 100.0
            curList[criterionIndex] = rounded
            secScores[st.fullName] = curList
        }

        val updated = _studentScoresBySection.value.toMutableMap()
        updated[sectionId] = secScores
        _studentScoresBySection.value = updated

        // Immediately auto-sync all rows in Gradebook
        val totalMax = _criteria.value.sumOf { it.max }.coerceAtLeast(1.0)
        val currentGb = _gradebookBySection.value[sectionId] ?: emptyList()
        val updatedGb = currentGb.map { row ->
            val matchedStudent = students.find { it.id == row.studentId }
            val fullName = matchedStudent?.fullName ?: "${row.nom} ${row.prenom}".trim()
            val scores = secScores[fullName] ?: _criteria.value.map { it.max * 0.8 }
            val sum = scores.take(_criteria.value.size).sum()
            val finalScore = if (Math.abs(totalMax - 20.0) < 0.01) sum else (sum / totalMax) * 20.0
            val rounded = Math.round(finalScore.coerceIn(0.0, 20.0) * 100.0) / 100.0
            row.copy(activityScore = rounded)
        }
        val updatedGbMap = _gradebookBySection.value.toMutableMap()
        updatedGbMap[sectionId] = updatedGb
        _gradebookBySection.value = updatedGbMap

        saveToPrefs()
    }

    fun syncContinuousAssessmentToGradebook(sectionId: Long) {
        val secScores = _studentScoresBySection.value[sectionId] ?: emptyMap()
        val currentGb = _gradebookBySection.value[sectionId] ?: emptyList()
        val students = _studentsBySection.value[sectionId] ?: emptyList()
        val totalMax = _criteria.value.sumOf { it.max }.coerceAtLeast(1.0)

        val updatedRows = currentGb.map { row ->
            val matchedStudent = students.find { it.id == row.studentId }
            val fullName = matchedStudent?.fullName ?: "${row.nom} ${row.prenom}"
            val scores = secScores[fullName] ?: _criteria.value.map { it.max * 0.8 }
            val sum = scores.take(_criteria.value.size).sum()
            val finalScore = if (Math.abs(totalMax - 20.0) < 0.01) sum else (sum / totalMax) * 20.0
            val rounded = Math.round(finalScore.coerceIn(0.0, 20.0) * 100.0) / 100.0
            row.copy(activityScore = rounded)
        }

        val updatedMap = _gradebookBySection.value.toMutableMap()
        updatedMap[sectionId] = updatedRows
        _gradebookBySection.value = updatedMap
        saveToPrefs()
    }

    fun updateGradebookRow(sectionId: Long, updatedRow: GradebookRow) {
        val current = _gradebookBySection.value[sectionId] ?: emptyList()
        val newRows = current.map { if (it.id == updatedRow.id) updatedRow else it }
        val updatedMap = _gradebookBySection.value.toMutableMap()
        updatedMap[sectionId] = newRows
        _gradebookBySection.value = updatedMap

        // Sync back to student individual assessment criteria proportionally
        val students = _studentsBySection.value[sectionId] ?: emptyList()
        val matchedStudent = students.find { it.id == updatedRow.studentId }
        val fullName = matchedStudent?.fullName ?: "${updatedRow.nom} ${updatedRow.prenom}".trim()
        val ratio = (updatedRow.activityScore / 20.0).coerceIn(0.0, 1.0)
        val secScores = (_studentScoresBySection.value[sectionId] ?: emptyMap()).toMutableMap()
        val newScores = _criteria.value.map { Math.round(it.max * ratio * 100.0) / 100.0 }
        secScores[fullName] = newScores
        val updatedScores = _studentScoresBySection.value.toMutableMap()
        updatedScores[sectionId] = secScores
        _studentScoresBySection.value = updatedScores

        saveToPrefs()
    }

    fun exportFullSerializedState(): String {
        val root = JSONObject()
        val prof = _teacherProfile.value
        val profObj = JSONObject().apply {
            put("schoolName", prof.schoolName)
            put("teacher", prof.teacher)
            put("year", prof.year)
            put("subject", prof.subject)
        }
        root.put("profile", profObj)
        root.put("accentColor", _accentColor.value)
        root.put("accentColorHex", String.format("#%06X", (0xFFFFFF and _accentColor.value.toInt())))
        root.put("isDarkMode", _isDarkMode.value)
        root.put("stepSize", _stepSize.value)

        val critArr = JSONArray()
        _criteria.value.forEach { c ->
            critArr.put(JSONObject().apply {
                put("id", c.id)
                put("name", c.name)
                put("max", c.max)
                put("score", c.score)
                put("icon", c.icon)
                put("colorHex", c.colorHex)
                put("color", c.colorHex)
            })
        }
        root.put("criteria", critArr)

        val secArr = JSONArray()
        _sections.value.forEach { sec ->
            secArr.put(JSONObject().apply {
                put("id", exportSectionKey(sec.id))
                put("name", sec.name)
                put("code", sec.code)
                put("level", sec.level)
                put("year", sec.year)
                put("subject", sec.subject)
                put("roomNumber", sec.roomNumber)
                put("rows", sec.rows)
                put("cols", sec.cols)
                put("deskSide", sec.deskSide)
                put("deskScale", sec.deskScale)
            })
        }
        root.put("sections", secArr)

        val studentsObj = JSONObject()
        _studentsBySection.value.forEach { (secId, list) ->
            val sArr = JSONArray()
            list.forEach { s ->
                sArr.put(JSONObject().apply {
                    put("id", s.id.toString())
                    put("sectionId", exportSectionKey(s.sectionId))
                    put("fullName", s.fullName)
                    put("matricule", s.matricule)
                    put("birthDate", s.birthDate)
                    put("status", s.status)
                })
            }
            studentsObj.put(exportSectionKey(secId), sArr)
        }
        root.put("studentsBySection", studentsObj)

        val seatObj = JSONObject()
        _seatOrderBySection.value.forEach { (secId, list) ->
            val arr = JSONArray()
            list.forEach { arr.put(it) }
            seatObj.put(exportSectionKey(secId), arr)
        }
        root.put("seatOrderBySection", seatObj)

        val scoresObj = JSONObject()
        _studentScoresBySection.value.forEach { (secId, map) ->
            val mObj = JSONObject()
            map.forEach { (stName, scores) ->
                val arr = JSONArray()
                scores.forEach { arr.put(it) }
                mObj.put(stName, arr)
            }
            scoresObj.put(exportSectionKey(secId), mObj)
        }
        root.put("studentScoresBySection", scoresObj)

        val gbObj = JSONObject()
        _gradebookBySection.value.forEach { (secId, rows) ->
            val arr = JSONArray()
            rows.forEach { r ->
                arr.put(JSONObject().apply {
                    put("id", r.id.toString())
                    put("studentId", r.studentId.toString())
                    put("matricule", r.matricule)
                    put("nom", r.nom)
                    put("prenom", r.prenom)
                    put("dateNaissance", r.dateNaissance)
                    put("date_n", r.dateNaissance)
                    put("activityScore", r.activityScore)
                    put("activity", r.activityScore)
                    put("homeworkScore", r.homeworkScore)
                    put("homework", r.homeworkScore)
                    put("examScore", r.examScore)
                    put("exam", r.examScore)
                    put("observation", r.observation)
                    put("obs", r.observation)
                    put("calculatedAverage", r.calculatedAverage)
                })
            }
            gbObj.put(exportSectionKey(secId), arr)
        }
        root.put("gradebookBySection", gbObj)

        val attObj = JSONObject()
        _attendanceBySection.value.forEach { (secId, map) ->
            val mObj = JSONObject()
            map.forEach { (stName, stStatus) ->
                mObj.put(stName, if (stStatus == AttendanceStatus.ABSENT) "absent" else "present")
            }
            attObj.put(exportSectionKey(secId), mObj)
        }
        root.put("attendanceBySection", attObj)
        root.put("selectedSectionId", exportSectionKey(_selectedSectionId.value))

        return root.toString()
    }

    fun applySerializedState(jsonStr: String, suppressCloudNotify: Boolean = false): Boolean {
        if (jsonStr.isBlank()) return false
        return try {
            val root = JSONObject(jsonStr)

            if (root.has("profile")) {
                val p = root.getJSONObject("profile")
                _teacherProfile.value = TeacherProfile(
                    schoolName = p.optString("schoolName", _teacherProfile.value.schoolName),
                    teacher = p.optString("teacher", _teacherProfile.value.teacher),
                    year = p.optString("year", _teacherProfile.value.year),
                    subject = p.optString("subject", _teacherProfile.value.subject)
                )
            }

            if (root.has("accentColorHex")) {
                try {
                    val parsedInt = android.graphics.Color.parseColor(root.getString("accentColorHex"))
                    _accentColor.value = (parsedInt.toLong() and 0xFFFFFFFFL) or 0xFF000000L
                } catch (_: Exception) {
                    if (root.has("accentColor")) _accentColor.value = (root.getLong("accentColor") and 0xFFFFFFFFL) or 0xFF000000L
                }
            } else if (root.has("accentColor")) {
                _accentColor.value = (root.getLong("accentColor") and 0xFFFFFFFFL) or 0xFF000000L
            }
            if (root.has("isDarkMode")) _isDarkMode.value = root.getBoolean("isDarkMode")
            if (root.has("stepSize")) {
                val step = root.getDouble("stepSize")
                _stepSize.value = if (step == 0.25 || step == 0.5) step else 0.5
            }

            if (root.has("criteria")) {
                val arr = root.getJSONArray("criteria")
                val list = mutableListOf<AssessmentCriterion>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(
                        AssessmentCriterion(
                            id = parseFlexibleId(obj.opt("id")).toInt(),
                            name = obj.optString("name", "معيار ${i + 1}"),
                            max = obj.optDouble("max", 2.0),
                            score = obj.optDouble("score", 1.0),
                            icon = obj.optString("icon", "★"),
                            colorHex = obj.optString("colorHex", obj.optString("color", "#5349D8"))
                        )
                    )
                }
                if (list.isNotEmpty()) _criteria.value = list
            }

            if (root.has("sections")) {
                val arr = root.getJSONArray("sections")
                val secList = mutableListOf<Section>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val rawKey = obj.opt("id")?.toString() ?: "${i + 1}"
                    val numId = parseFlexibleId(rawKey)
                    sectionKeyAliases[numId] = rawKey
                    secList.add(
                        Section(
                            id = numId,
                            name = obj.optString("name", "قسم"),
                            code = obj.optString("code", ""),
                            level = obj.optString("level", "الأولى متوسط"),
                            year = obj.optString("year", "2026 / 2027"),
                            subject = obj.optString("subject", "الرياضيات"),
                            roomNumber = obj.optString("roomNumber", "01"),
                            rows = obj.optInt("rows", 4),
                            cols = obj.optInt("cols", 3),
                            deskSide = obj.optString("deskSide", "right"),
                            deskScale = obj.optInt("deskScale", 100)
                        )
                    )
                }
                if (secList.isNotEmpty()) {
                    _sections.value = secList
                    val desiredSel = if (root.has("selectedSectionId")) {
                        parseFlexibleId(root.opt("selectedSectionId"))
                    } else {
                        _selectedSectionId.value
                    }
                    _selectedSectionId.value = if (desiredSel in secList.map { it.id }) desiredSel else secList.first().id
                }
            }

            if (root.has("studentsBySection")) {
                val obj = root.getJSONObject("studentsBySection")
                val sMap = mutableMapOf<Long, List<Student>>()
                obj.keys().forEach { key ->
                    val secId = parseFlexibleId(key)
                    sectionKeyAliases[secId] = key
                    val arr = obj.getJSONArray(key)
                    val list = mutableListOf<Student>()
                    for (i in 0 until arr.length()) {
                        val so = arr.getJSONObject(i)
                        list.add(
                            Student(
                                id = parseFlexibleId(so.opt("id")),
                                sectionId = secId,
                                fullName = so.optString("fullName", ""),
                                matricule = so.optString("matricule", ""),
                                birthDate = so.optString("birthDate", ""),
                                status = so.optString("status", "منتظم")
                            )
                        )
                    }
                    sMap[secId] = list
                }
                if (sMap.isNotEmpty()) _studentsBySection.value = sMap
            }

            if (root.has("seatOrderBySection")) {
                val obj = root.getJSONObject("seatOrderBySection")
                val seatMap = mutableMapOf<Long, List<String>>()
                obj.keys().forEach { key ->
                    val secId = parseFlexibleId(key)
                    val arr = obj.getJSONArray(key)
                    val list = mutableListOf<String>()
                    for (i in 0 until arr.length()) {
                        list.add(arr.optString(i, ""))
                    }
                    seatMap[secId] = list
                }
                if (seatMap.isNotEmpty()) _seatOrderBySection.value = seatMap
            }

            if (root.has("studentScoresBySection")) {
                val obj = root.getJSONObject("studentScoresBySection")
                val scoreMap = mutableMapOf<Long, Map<String, List<Double>>>()
                obj.keys().forEach { key ->
                    val secId = parseFlexibleId(key)
                    val stObj = obj.getJSONObject(key)
                    val map = mutableMapOf<String, List<Double>>()
                    stObj.keys().forEach { stName ->
                        val arr = stObj.getJSONArray(stName)
                        val sList = mutableListOf<Double>()
                        for (i in 0 until arr.length()) {
                            sList.add(arr.optDouble(i, 1.0))
                        }
                        map[stName] = sList
                    }
                    scoreMap[secId] = map
                }
                if (scoreMap.isNotEmpty()) _studentScoresBySection.value = scoreMap
            }

            if (root.has("gradebookBySection")) {
                val obj = root.getJSONObject("gradebookBySection")
                val gbMap = mutableMapOf<Long, List<GradebookRow>>()
                obj.keys().forEach { key ->
                    val secId = parseFlexibleId(key)
                    val arr = obj.getJSONArray(key)
                    val rList = mutableListOf<GradebookRow>()
                    for (i in 0 until arr.length()) {
                        val ro = arr.getJSONObject(i)
                        val rId = parseFlexibleId(ro.opt("id"))
                        val stId = parseFlexibleId(ro.opt("studentId") ?: ro.opt("id"))
                        rList.add(
                            GradebookRow(
                                id = rId,
                                studentId = stId,
                                matricule = ro.optString("matricule", ""),
                                nom = ro.optString("nom", ""),
                                prenom = ro.optString("prenom", ""),
                                dateNaissance = ro.optString("dateNaissance", ro.optString("date_n", "")),
                                activityScore = if (ro.has("activityScore")) ro.optDouble("activityScore", 10.0) else ro.optDouble("activity", 10.0),
                                homeworkScore = if (ro.has("homeworkScore")) ro.optDouble("homeworkScore", 14.0) else ro.optDouble("homework", 14.0),
                                examScore = if (ro.has("examScore")) ro.optDouble("examScore", 15.0) else ro.optDouble("exam", 15.0),
                                observation = ro.optString("observation", ro.optString("obs", ""))
                            )
                        )
                    }
                    gbMap[secId] = rList
                }
                if (gbMap.isNotEmpty()) _gradebookBySection.value = gbMap
            }

            if (root.has("attendanceBySection")) {
                val obj = root.getJSONObject("attendanceBySection")
                val attMap = mutableMapOf<Long, Map<String, AttendanceStatus>>()
                obj.keys().forEach { key ->
                    val secId = parseFlexibleId(key)
                    val mapObj = obj.getJSONObject(key)
                    val stMap = mutableMapOf<String, AttendanceStatus>()
                    mapObj.keys().forEach { stName ->
                        val v = mapObj.optString(stName, "present")
                        stMap[stName] = if (v == "absent") AttendanceStatus.ABSENT else AttendanceStatus.PRESENT
                    }
                    attMap[secId] = stMap
                }
                _attendanceBySection.value = attMap
            }

            saveToPrefs(suppressCloudNotify)
            true
        } catch (e: Exception) {
            false
        }
    }
}
