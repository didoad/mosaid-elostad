package com.example.data.model

data class TeacherProfile(
    val schoolName: String = "متوسطة الأمير عبد القادر",
    val teacher: String = "الأستاذ دجمي زازوي",
    val year: String = "2026 / 2027",
    val subject: String = "مادة الرياضيات"
)

data class LevelInfo(
    val code: String,
    val label: String
)

data class Section(
    val id: Long,
    val name: String,
    val code: String,
    val level: String,
    val year: String = "2026 / 2027",
    val subject: String = "الرياضيات",
    val roomNumber: String = "01",
    val rows: Int = 4,
    val cols: Int = 3,
    val deskSide: String = "right", // "right" or "left" of the board
    val deskScale: Int = 100
)

data class Student(
    val id: Long,
    val sectionId: Long,
    val fullName: String,
    val matricule: String = "",
    val birthDate: String = "",
    val status: String = "منتظم"
)

enum class AttendanceStatus {
    PRESENT,
    ABSENT
}

data class AssessmentCriterion(
    val id: Int,
    val name: String,
    val max: Double,
    val score: Double = 0.0,
    val icon: String = "★",
    val colorHex: String = "#5349D8"
)

data class GradebookRow(
    val id: Long,
    val studentId: Long,
    val matricule: String,
    val nom: String,
    val prenom: String,
    val dateNaissance: String,
    val activityScore: Double = 0.0,
    val homeworkScore: Double = 0.0,
    val examScore: Double = 0.0,
    val observation: String = ""
) {
    val calculatedAverage: Double
        get() {
            // Standard Algerian middle school calculation: (Continuous + Homework + Exam * 2) / 4
            // or (Activity + Homework + Exam) / 3 if exam is out of 20
            val count = (if (activityScore > 0) 1 else 0) + (if (homeworkScore > 0) 1 else 0) + (if (examScore > 0) 2 else 0)
            if (count == 0) return 0.0
            val total = activityScore + homeworkScore + (examScore * 2)
            return (total / 4.0).coerceIn(0.0, 20.0)
        }

    val autoObservation: String
        get() {
            val avg = calculatedAverage
            return when {
                avg >= 18.0 -> "ممتاز"
                avg >= 16.0 -> "جيد جداً"
                avg >= 14.0 -> "جيد"
                avg >= 12.0 -> "قريب من الجيد"
                avg >= 10.0 -> "مقبول"
                avg > 0.0 -> "دون الوسط"
                else -> if (observation.isNotBlank()) observation else "—"
            }
        }
}
