package com.example.data.sync

import android.content.Context
import android.os.Build
import android.util.Log
import com.example.R
import com.example.data.repository.TeacherRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

sealed interface SyncState {
    object Idle : SyncState
    object InProgress : SyncState
    data class Success(val lastSyncTime: String, val message: String) : SyncState
    data class Error(val message: String) : SyncState
}

class CloudSyncManager(
    private val context: Context,
    private val repository: TeacherRepository
) {
    private val tag = "CloudSyncManager"
    private val prefs = context.getSharedPreferences("djemi_ai_sync", Context.MODE_PRIVATE)
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(
        context.getString(R.string.firestore_database_id)
    )
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var snapshotRegistration: ListenerRegistration? = null
    private var activeUserId: String? = null
    private var isApplyingRemoteUpdate = false

    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _deviceType = MutableStateFlow(detectDeviceType())
    val deviceType: StateFlow<String> = _deviceType.asStateFlow()

    private fun getDeviceId(): String {
        val existing = prefs.getString("djemi_android_device_id", null)
        if (!existing.isNullOrBlank()) return existing
        val created = "android_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}"
        prefs.edit().putString("djemi_android_device_id", created).apply()
        return created
    }

    private fun detectDeviceType(): String {
        val model = Build.MODEL.lowercase(Locale.ROOT)
        val manufacturer = Build.MANUFACTURER.lowercase(Locale.ROOT)
        return when {
            model.contains("subsystem") || model.contains("wsa") || manufacturer.contains("microsoft") -> "حاسوب (Windows WSA)"
            model.contains("chrome") || Build.BRAND.lowercase(Locale.ROOT).contains("chromium") -> "حاسوب (Chromebook)"
            model.contains("bluestacks") || model.contains("vbox") || Build.HARDWARE.contains("goldfish") -> "محاكي أندرويد"
            else -> "هاتف ذكي (Android ${Build.VERSION.RELEASE})"
        }
    }

    fun startSyncForUser(userId: String) {
        if (activeUserId == userId && snapshotRegistration != null) return
        stopSync()
        activeUserId = userId

        registerDevice(userId, "bidirectional")
        val localDeviceId = getDeviceId()

        val docRef = db.collection("users").document(userId).collection("sync").document("bundle")
        snapshotRegistration = docRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e(tag, "Snapshot listener error: ${error.message}", error)
                _syncState.value = SyncState.Error("خطأ في المزامنة السحابية: ${error.localizedMessage}")
                return@addSnapshotListener
            }

            if (snapshot != null && snapshot.exists()) {
                val remotePayload = snapshot.getString("payloadJson")
                val remoteSenderId = snapshot.getString("senderDeviceId") ?: "حاسوب المعلم"
                val remoteSenderKey = snapshot.getString("senderDeviceKey") ?: ""
                val remoteTime = snapshot.getString("syncTimestamp") ?: formatCurrentTime()

                // Prevent self-echo from this exact Android device instance
                if (remoteSenderKey == localDeviceId) {
                    return@addSnapshotListener
                }

                if (!remotePayload.isNullOrBlank() && !isApplyingRemoteUpdate) {
                    try {
                        isApplyingRemoteUpdate = true
                        val applied = repository.applySerializedState(remotePayload)
                        if (applied) {
                            _syncState.value = SyncState.Success(
                                lastSyncTime = remoteTime,
                                message = "تمت المزامنة لحظياً من: $remoteSenderId"
                            )
                        }
                    } catch (e: Exception) {
                        Log.e(tag, "Failed to apply remote payload", e)
                    } finally {
                        isApplyingRemoteUpdate = false
                    }
                }
            } else {
                pushLocalDataToCloud()
            }
        }
    }

    private fun registerDevice(userId: String, direction: String) {
        scope.launch {
            try {
                val deviceId = getDeviceId()
                val deviceName = "هاتف المعلم (${Build.MANUFACTURER} ${Build.MODEL})"
                val devDoc = mapOf(
                    "id" to deviceId,
                    "name" to deviceName,
                    "type" to "mobile",
                    "os" to "Android ${Build.VERSION.RELEASE}",
                    "isCurrent" to false,
                    "status" to "online",
                    "lastActive" to formatCurrentTime(),
                    "lastSyncDirection" to direction,
                    "serverTimestamp" to FieldValue.serverTimestamp()
                )
                db.collection("users").document(userId)
                    .collection("devices").document(deviceId)
                    .set(devDoc, SetOptions.merge())
                    .await()
            } catch (e: Exception) {
                Log.w(tag, "Device registration error: ${e.message}")
            }
        }
    }

    fun pushLocalDataToCloud() {
        val userId = auth.currentUser?.uid ?: return
        if (isApplyingRemoteUpdate) return

        scope.launch {
            try {
                _syncState.value = SyncState.InProgress
                val serializedPayload = repository.exportFullSerializedState()
                val currentTime = formatCurrentTime()
                val deviceName = "هاتف المعلم (${Build.MANUFACTURER} ${Build.MODEL})"
                val deviceId = getDeviceId()

                val syncDoc = mapOf(
                    "userId" to userId,
                    "payloadJson" to serializedPayload,
                    "syncTimestamp" to currentTime,
                    "senderDeviceId" to deviceName,
                    "senderDeviceKey" to deviceId,
                    "deviceCategory" to _deviceType.value,
                    "serverTimestamp" to FieldValue.serverTimestamp()
                )

                db.collection("users").document(userId)
                    .collection("sync").document("bundle")
                    .set(syncDoc, SetOptions.merge())
                    .await()

                val teacherProf = repository.teacherProfile.value
                val profileDoc = mapOf(
                    "userId" to userId,
                    "fullName" to teacherProf.teacher,
                    "schoolName" to teacherProf.schoolName,
                    "subject" to teacherProf.subject,
                    "academicYear" to teacherProf.year,
                    "email" to (auth.currentUser?.email ?: ""),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                db.collection("users").document(userId)
                    .set(profileDoc, SetOptions.merge())
                    .await()

                registerDevice(userId, "upload")

                _syncState.value = SyncState.Success(
                    lastSyncTime = currentTime,
                    message = "تم حفظ ومزامنة البيانات مع الحاسوب بنجاح"
                )
            } catch (e: Exception) {
                Log.e(tag, "Failed to push data to cloud: ${e.message}", e)
                _syncState.value = SyncState.Error("تعذر حفظ البيانات سحابياً: ${e.localizedMessage}")
            }
        }
    }

    fun stopSync() {
        snapshotRegistration?.remove()
        snapshotRegistration = null
        activeUserId = null
        _syncState.value = SyncState.Idle
    }

    private fun formatCurrentTime(): String {
        val sdf = SimpleDateFormat("HH:mm:ss - yyyy/MM/dd", Locale.getDefault())
        return sdf.format(Date())
    }
}
