package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AssessmentCriterion
import com.example.data.model.AttendanceStatus
import com.example.data.model.GradebookRow
import com.example.data.model.Section
import com.example.data.model.Student
import com.example.data.model.TeacherProfile
import com.example.data.repository.TeacherRepository
import com.example.data.sync.CloudSyncManager
import com.example.data.sync.SyncState
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppNavTab(val title: String, val icon: String) {
    OVERVIEW("الأقسام", "book"),
    SEATING("مخطط الجلوس", "grid"),
    GRADEBOOK("دفتر التنقيط", "gradebook"),
    CRITERIA("التقويم المستمر", "calendar"),
    SETTINGS("المظهر والإعدادات", "settings")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = TeacherRepository(application)
    val cloudSyncManager = CloudSyncManager(application, repository)

    val syncState: StateFlow<SyncState> = cloudSyncManager.syncState
    val deviceType: StateFlow<String> = cloudSyncManager.deviceType

    init {
        repository.setOnDataChangedListener {
            cloudSyncManager.pushLocalDataToCloud()
        }
    }

    fun startSyncForUser(userId: String) {
        cloudSyncManager.startSyncForUser(userId)
    }

    fun stopSync() {
        cloudSyncManager.stopSync()
    }

    fun manualSync() {
        cloudSyncManager.pushLocalDataToCloud()
        showToast("جارٍ تحديث المزامنة مع السحابة والحاسوب...")
    }

    private val _currentTab = MutableStateFlow(AppNavTab.OVERVIEW)
    val currentTab: StateFlow<AppNavTab> = _currentTab.asStateFlow()

    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedLevelCodes = MutableStateFlow(listOf("1AM", "2AM", "3AM", "4AM"))
    val selectedLevelCodes: StateFlow<List<String>> = _selectedLevelCodes.asStateFlow()

    // Seating screen states
    private val _isMoveMode = MutableStateFlow(false)
    val isMoveMode: StateFlow<Boolean> = _isMoveMode.asStateFlow()

    private val _isAttendanceMode = MutableStateFlow(false)
    val isAttendanceMode: StateFlow<Boolean> = _isAttendanceMode.asStateFlow()

    private val _selectedSeatIndex = MutableStateFlow<Int?>(null)
    val selectedSeatIndex: StateFlow<Int?> = _selectedSeatIndex.asStateFlow()

    private val _assessmentStudent = MutableStateFlow<String?>(null)
    val assessmentStudent: StateFlow<String?> = _assessmentStudent.asStateFlow()

    // Data delegations from repository
    val teacherProfile = repository.teacherProfile
    val sections = repository.sections
    val selectedSectionId = repository.selectedSectionId
    val studentsBySection = repository.studentsBySection
    val seatOrderBySection = repository.seatOrderBySection
    val attendanceBySection = repository.attendanceBySection
    val studentScoresBySection = repository.studentScoresBySection
    val gradebookBySection = repository.gradebookBySection
    val accentColor = repository.accentColor
    val isDarkMode = repository.isDarkMode
    val allLevels = repository.allLevels
    val criteria: StateFlow<List<AssessmentCriterion>> = repository.criteria
    val stepSize: StateFlow<Double> = repository.stepSize

    // Active Section
    val currentSection: StateFlow<Section?> = combine(sections, selectedSectionId) { secList, id ->
        secList.find { it.id == id } ?: secList.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Current students
    val currentStudents: StateFlow<List<Student>> = combine(studentsBySection, selectedSectionId) { sMap, id ->
        sMap[id] ?: emptyList()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Filtered students by search
    val filteredStudents: StateFlow<List<Student>> = combine(currentStudents, _searchQuery) { list, query ->
        if (query.isBlank()) list
        else list.filter { it.fullName.contains(query, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Current seating order
    val currentSeats: StateFlow<List<String>> = combine(seatOrderBySection, selectedSectionId) { seatMap, id ->
        seatMap[id] ?: emptyList()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Current gradebook rows
    val currentGradebook: StateFlow<List<GradebookRow>> = combine(gradebookBySection, selectedSectionId) { gbMap, id ->
        gbMap[id] ?: emptyList()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Overall attendance rate
    val attendanceRate: StateFlow<Int> = combine(attendanceBySection, selectedSectionId, currentStudents) { attMap, secId, students ->
        if (students.isEmpty()) return@combine 100
        val secAtt = attMap[secId] ?: emptyMap()
        val absentCount = secAtt.values.count { it == AttendanceStatus.ABSENT }
        val presentCount = students.size - absentCount
        ((presentCount.toDouble() / students.size.toDouble()) * 100).toInt().coerceIn(0, 100)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, 92)

    fun selectTab(tab: AppNavTab) {
        _currentTab.value = tab
    }

    fun showToast(msg: String) {
        viewModelScope.launch {
            _toastMessage.emit(msg)
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleLevelCode(code: String) {
        val current = _selectedLevelCodes.value
        _selectedLevelCodes.value = if (current.contains(code)) {
            if (current.size > 1) current - code else current
        } else {
            current + code
        }
    }

    fun selectAllLevels() {
        _selectedLevelCodes.value = allLevels.map { it.code }
    }

    fun selectSection(id: Long) {
        repository.selectSection(id)
        _selectedSeatIndex.value = null
        _assessmentStudent.value = null
    }

    fun addSection(name: String, level: String, year: String, initialStudents: List<String>) {
        repository.addSection(name, level, year, initialStudents)
        showToast("تم إنشاء القسم بنجاح وحفظ التلاميذ")
    }

    fun addSectionWithParsedStudents(name: String, level: String, year: String, parsedList: List<com.example.util.ParsedStudent>) {
        repository.addSectionWithParsedStudents(name, level, year, parsedList)
        showToast("تم إنشاء القسم بنجاح وإضافة ${parsedList.size} تلميذاً من الملف")
    }

    fun importDigitalStudents(parsedList: List<com.example.util.ParsedStudent>) {
        val count = repository.importDigitalStudents(parsedList)
        showToast("تم استيراد $count تلميذاً من ملف الرقمنة بنجاح")
    }

    fun exportGradebookXlsx(context: android.content.Context) {
        val sec = currentSection.value ?: return
        val rows = currentGradebook.value
        val bytes = com.example.util.ExcelHelper.createGradebookXlsx(sec.name, sec.year, rows)
        val fileName = "دفتر_تنقيط_${sec.name}.xlsx"
        com.example.util.ExcelHelper.shareFile(context, fileName, bytes, "تصدير دفتر تنقيط ${sec.name}")
        showToast("تم إنشاء وتصدير ملف Excel بنجاح")
    }

    fun exportSectionStudentsXlsx(context: android.content.Context) {
        val sec = currentSection.value ?: return
        val studentsList = currentStudents.value.map {
            com.example.util.ParsedStudent(fullName = it.fullName, matricule = it.matricule, birthDate = it.birthDate, sectionName = sec.name)
        }
        val bytes = com.example.util.ExcelHelper.createStudentsListXlsx(sec.name, studentsList)
        val fileName = "قائمة_تلاميذ_${sec.name}.xlsx"
        com.example.util.ExcelHelper.shareFile(context, fileName, bytes, "تصدير قائمة تلاميذ ${sec.name}")
        showToast("تم تصدير قائمة التلاميذ بصيغة XLSX بنجاح")
    }

    fun downloadTemplateXlsx(context: android.content.Context) {
        val bytes = com.example.util.ExcelHelper.createSectionTemplateXlsx()
        val fileName = "نموذج_استيراد_التلاميذ.xlsx"
        com.example.util.ExcelHelper.shareFile(context, fileName, bytes, "تنزيل نموذج Excel للتلاميذ")
        showToast("تم تجهيز نموذج XLSX للتلاميذ")
    }

    fun updateSection(section: Section) {
        repository.updateSection(section)
        showToast("تم حفظ تعديل القسم")
    }

    fun deleteSection(id: Long) {
        repository.deleteSection(id)
        showToast("تم حذف القسم")
    }

    fun addStudent(name: String) {
        val secId = selectedSectionId.value
        repository.addStudent(secId, name)
        showToast("تمت إضافة التلميذ إلى القسم")
    }

    fun renameStudent(studentId: Long, newName: String) {
        val secId = selectedSectionId.value
        repository.renameStudent(secId, studentId, newName)
        showToast("تم تعديل اسم التلميذ")
    }

    fun deleteStudent(studentId: Long) {
        val secId = selectedSectionId.value
        repository.deleteStudent(secId, studentId)
        showToast("تم حذف التلميذ من القسم")
    }

    fun clearAllStudents() {
        val secId = selectedSectionId.value
        repository.clearSectionStudents(secId)
        showToast("تم مسح قائمة تلاميذ القسم")
    }

    fun setMoveMode(enabled: Boolean) {
        _isMoveMode.value = enabled
        _selectedSeatIndex.value = null
    }

    fun setAttendanceMode(enabled: Boolean) {
        _isAttendanceMode.value = enabled
        _selectedSeatIndex.value = null
    }

    fun onSeatClicked(index: Int) {
        val secId = selectedSectionId.value
        val seats = currentSeats.value
        val studentName = seats.getOrNull(index) ?: ""

        if (_isAttendanceMode.value) {
            if (studentName.isNotBlank()) {
                repository.toggleAttendance(secId, studentName)
                val isNowAbsent = (repository.attendanceBySection.value[secId]?.get(studentName) ?: AttendanceStatus.PRESENT) == AttendanceStatus.ABSENT
                showToast(if (isNowAbsent) "تم تسجيل $studentName غائباً" else "تم تسجيل $studentName حاضراً")
            }
            return
        }

        if (_isMoveMode.value) {
            val prev = _selectedSeatIndex.value
            if (prev == null) {
                if (studentName.isNotBlank()) {
                    _selectedSeatIndex.value = index
                    showToast("تم اختيار $studentName — اضغط على المقعد الهدف للنقل")
                }
            } else if (prev == index) {
                _selectedSeatIndex.value = null
            } else {
                repository.swapSeats(secId, prev, index)
                _selectedSeatIndex.value = null
                showToast("تم نقل التلميذ إلى المقعد الجديد")
            }
            return
        }

        // Default: Open Assessment if student exists
        if (studentName.isNotBlank()) {
            _assessmentStudent.value = studentName
        }
    }

    fun closeAssessmentModal() {
        _assessmentStudent.value = null
    }

    fun goToNextStudent(direction: Int) {
        val currentName = _assessmentStudent.value ?: return
        val seated = currentSeats.value.filter { it.isNotBlank() }
        val idx = seated.indexOf(currentName)
        val nextIdx = idx + direction
        if (nextIdx in seated.indices) {
            _assessmentStudent.value = seated[nextIdx]
        }
    }

    fun updateScore(studentName: String, criterionIndex: Int, delta: Double) {
        val secId = selectedSectionId.value
        repository.updateStudentScore(secId, studentName, criterionIndex, delta)
    }

    fun applyBulkScore(criterionIndex: Int, delta: Double) {
        val secId = selectedSectionId.value
        repository.applyBulkScoreToAll(secId, criterionIndex, delta)
        val critName = criteria.value.getOrNull(criterionIndex)?.name ?: "المعيار"
        showToast(if (delta > 0) "تمت إضافة $delta نقطة لجميع التلاميذ في $critName" else "تم خصم ${-delta} نقطة لجميع التلاميذ في $critName")
    }

    fun setStepSize(step: Double) {
        repository.setStepSize(step)
        showToast("تم ضبط مقدار الخطوة على $step نقطة")
    }

    fun addCriterion(name: String, max: Double, icon: String) {
        repository.addCriterion(name, max, icon)
        showToast("تمت إضافة معيار: $name بنجاح")
    }

    fun updateCriterion(id: Int, name: String, max: Double, icon: String) {
        repository.updateCriterion(id, name, max, icon)
        showToast("تم تحديث المعيار")
    }

    fun deleteCriterion(id: Int) {
        repository.deleteCriterion(id)
        showToast("تم حذف المعيار")
    }

    fun resetDefaultCriteria() {
        repository.resetDefaultCriteria()
        showToast("تمت استعادة المعايير الافتراضية")
    }

    fun shuffleSeats() {
        val secId = selectedSectionId.value
        repository.shuffleSeats(secId)
        showToast("تم توزيع التلاميذ عشوائياً على المقاعد")
    }

    fun updateRoomConfig(rows: Int, cols: Int, deskSide: String, roomNumber: String) {
        val secId = selectedSectionId.value
        repository.updateRoomConfig(secId, rows, cols, deskSide, roomNumber)
        showToast("تم تحديث إعدادات القاعة وتوزيع المقاعد")
    }

    fun updateDeskScale(scale: Int) {
        val secId = selectedSectionId.value
        repository.updateDeskScale(secId, scale)
    }

    fun printVisualSeatingChart(context: android.content.Context, scalePercent: Int = 95) {
        val sec = currentSection.value ?: return
        val prof = teacherProfile.value
        val seats = currentSeats.value
        com.example.util.PrintHelper.printSeatingChart(context, sec, prof, seats, scalePercent, sec.deskScale)
        showToast("تم تجهيز مخطط الجلوس للطباعة أو الحفظ بصيغة PDF")
    }

    fun syncContinuousAssessment() {
        val secId = selectedSectionId.value
        repository.syncContinuousAssessmentToGradebook(secId)
        showToast("تم نسخ نقاط التقويم المستمر إلى دفتر التنقيط بنجاح!")
    }

    fun updateGradebookRow(row: GradebookRow) {
        val secId = selectedSectionId.value
        repository.updateGradebookRow(secId, row)
        showToast("تم حفظ نقاط ${row.nom} ${row.prenom}")
    }

    fun setTeacherProfile(profile: TeacherProfile) {
        repository.setTeacherProfile(profile)
        showToast("تم حفظ بطاقة الأستاذ بنجاح")
    }

    fun setAccentColor(color: Long) {
        repository.setAccentColor(color)
        showToast("تم تغيير اللون الرئيسي للتطبيق")
    }

    fun toggleDarkMode() {
        repository.toggleDarkMode()
    }
}
