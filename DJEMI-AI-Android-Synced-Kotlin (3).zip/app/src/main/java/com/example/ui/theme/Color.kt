package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Default Algerian Education / DJEMI-AI theme palette
val PrimaryIndigo = Color(0xFF5349D8)
val PrimaryIndigoLight = Color(0xFF7067E6)
val PrimaryIndigoDark = Color(0xFF382FAD)

val EmeraldSuccess = Color(0xFF10B981)
val CoralAbsent = Color(0xFFEF4444)
val AmberWarning = Color(0xFFF59E0B)
val SkyAccent = Color(0xFF0EA5E9)

// Preset accent colors for color customization
val PresetColors = listOf(
    0xFF5349D8, // Royal Purple (Default)
    0xFF2563EB, // Sapphire Blue
    0xFF059669, // Emerald Green
    0xFFD97706, // Warm Amber
    0xFFE11D48, // Rose Red
    0xFF0891B2, // Cyan Teal
    0xFF475569  // Slate Gray
)

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
