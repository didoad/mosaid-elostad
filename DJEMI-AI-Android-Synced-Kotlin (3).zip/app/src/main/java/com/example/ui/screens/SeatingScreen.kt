package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.RoomPreferences
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AttendanceStatus
import com.example.ui.components.RoomConfigDialog
import com.example.ui.theme.CoralAbsent
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeatingScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val currentSec by viewModel.currentSection.collectAsStateWithLifecycle()
    val sections by viewModel.sections.collectAsStateWithLifecycle()
    val seats by viewModel.currentSeats.collectAsStateWithLifecycle()
    val students by viewModel.currentStudents.collectAsStateWithLifecycle()
    val attendanceMap by viewModel.attendanceBySection.collectAsStateWithLifecycle()
    val scoresMap by viewModel.studentScoresBySection.collectAsStateWithLifecycle()
    val isMoveMode by viewModel.isMoveMode.collectAsStateWithLifecycle()
    val isAttendanceMode by viewModel.isAttendanceMode.collectAsStateWithLifecycle()
    val selectedSeatIndex by viewModel.selectedSeatIndex.collectAsStateWithLifecycle()
    val assessmentStudent by viewModel.assessmentStudent.collectAsStateWithLifecycle()
    val criteria by viewModel.criteria.collectAsStateWithLifecycle()
    val stepSize by viewModel.stepSize.collectAsStateWithLifecycle()

    val secId = currentSec?.id ?: 1L
    val currentSecAttendance = attendanceMap[secId] ?: emptyMap()
    val currentSecScores = scoresMap[secId] ?: emptyMap()

    var showRoomConfigDialog by remember { mutableStateOf(false) }
    var showPrintDialog by remember { mutableStateOf(false) }
    var printScalePercent by remember { mutableIntStateOf(95) }
    val deskScale = currentSec?.deskScale ?: 100
    var sectionDropdownExpanded by remember { mutableStateOf(false) }

    val rows = currentSec?.rows ?: 4
    val cols = currentSec?.cols ?: 3
    val deskSide = currentSec?.deskSide ?: "right"
    val roomNumber = currentSec?.roomNumber ?: "01"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("seating_screen")
    ) {
        // Top Toolbar: Section Selector & Classroom Info
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "تنظيم الصف والتجليس",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "حجرة التدريس $roomNumber",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Section Dropdown Picker
                    ExposedDropdownMenuBox(
                        expanded = sectionDropdownExpanded,
                        onExpandedChange = { sectionDropdownExpanded = !sectionDropdownExpanded }
                    ) {
                        Surface(
                            modifier = Modifier
                                .menuAnchor()
                                .clip(RoundedCornerShape(10.dp))
                                .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))
                                .clickable { sectionDropdownExpanded = true },
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "القسم: ${currentSec?.name ?: ""}",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = sectionDropdownExpanded)
                            }
                        }
                        ExposedDropdownMenu(
                            expanded = sectionDropdownExpanded,
                            onDismissRequest = { sectionDropdownExpanded = false }
                        ) {
                            sections.forEach { sec ->
                                DropdownMenuItem(
                                    text = { Text(sec.name, fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        viewModel.selectSection(sec.id)
                                        sectionDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                val absentCount = currentSecAttendance.values.count { it == AttendanceStatus.ABSENT }
                val presentCount = students.size - absentCount

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EmeraldSuccess.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "$presentCount حاضر",
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    if (absentCount > 0) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CoralAbsent.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "$absentCount غائب",
                                color = CoralAbsent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Text(
                        text = "· السعة: ${rows * cols * 2} مقعداً",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Actions Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Move Mode Toggle
            Button(
                onClick = {
                    viewModel.setMoveMode(!isMoveMode)
                    if (!isMoveMode) viewModel.setAttendanceMode(false)
                },
                colors = if (isMoveMode) ButtonDefaults.buttonColors() else ButtonDefaults.outlinedButtonColors(),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("move_mode_button")
            ) {
                Icon(Icons.Default.OpenWith, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isMoveMode) "إيقاف النقل" else "تعديل التجليس", fontSize = 12.sp)
            }

            // Attendance Mode Toggle
            Button(
                onClick = {
                    viewModel.setAttendanceMode(!isAttendanceMode)
                    if (!isAttendanceMode) viewModel.setMoveMode(false)
                },
                colors = if (isAttendanceMode) ButtonDefaults.buttonColors(containerColor = CoralAbsent) else ButtonDefaults.outlinedButtonColors(),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("attendance_mode_button")
            ) {
                Icon(Icons.Default.HowToReg, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isAttendanceMode) "إنهاء المناداة" else "وضع المناداة", fontSize = 12.sp)
            }

            // Shuffle Seats
            OutlinedButton(
                onClick = { viewModel.shuffleSeats() },
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("توزيع عشوائي", fontSize = 12.sp)
            }

            // Room Setup
            OutlinedButton(
                onClick = { showRoomConfigDialog = true },
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.RoomPreferences, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("حجم الحجرة", fontSize = 12.sp)
            }

            // Print Visual Chart
            OutlinedButton(
                onClick = { showPrintDialog = true },
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("طباعة المخطط", fontSize = 12.sp)
            }

            OutlinedButton(
                onClick = { viewModel.updateDeskScale((deskScale - 10).coerceAtLeast(65)) },
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("تصغير −", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = { viewModel.updateDeskScale((deskScale + 10).coerceAtMost(150)) },
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("تكبير + (${deskScale}%)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Active Mode Banner
        if (isMoveMode || isAttendanceMode) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = if (isAttendanceMode) CoralAbsent.copy(alpha = 0.12f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (isAttendanceMode)
                        "⚡ وضع المناداة مفعّل: اضغط على أي تلميذ لتسجيل غيابه فوراً."
                    else
                        "✣ وضع النقل مفعّل: اضغط على التلميذ أولاً ثم على المقعد الجديد لنقله أو التبديل.",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isAttendanceMode) CoralAbsent else MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Chalkboard and Teacher Desk
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Board row with teacher desk
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (deskSide == "right") {
                        TeacherDeskBox(modifier = Modifier.width(90.dp))
                    }

                    // Green Chalkboard with wooden frame
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF064E3B))
                            .border(3.dp, Color(0xFFB45309), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "السبورة",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    if (deskSide == "left") {
                        TeacherDeskBox(modifier = Modifier.width(90.dp))
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Scrollable Desk Grid
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        for (r in (rows - 1) downTo 0) {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                for (c in 0 until cols) {
                                    val deskIndex = (r * cols) + c
                                    DoubleDeskCard(
                                        deskIndex = deskIndex,
                                        deskScale = deskScale,
                                        seats = seats,
                                        selectedSeatIndex = selectedSeatIndex,
                                        attendanceMap = currentSecAttendance,
                                        isMoveMode = isMoveMode,
                                        isAttendanceMode = isAttendanceMode,
                                        onSeatClick = { idx -> viewModel.onSeatClicked(idx) }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Legend
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LegendItem(color = MaterialTheme.colorScheme.primary, text = "مقعد مشغول")
                    Spacer(modifier = Modifier.width(16.dp))
                    LegendItem(color = CoralAbsent, text = "غائب")
                    Spacer(modifier = Modifier.width(16.dp))
                    LegendItem(color = MaterialTheme.colorScheme.outlineVariant, text = "مقعد شاغر")
                }
            }
        }
    }

    // Print Visual Seating Dialog
    if (showPrintDialog) {
        AlertDialog(
            onDismissRequest = { showPrintDialog = false },
            title = { Text("طباعة ومشاركة مخطط الجلوس", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("مقياس الورقة في الطباعة (A4 Landscape): ${printScalePercent}%", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { printScalePercent = (printScalePercent - 5).coerceAtLeast(60) }, modifier = Modifier.weight(1f)) {
                            Text("تصغير −", fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = { printScalePercent = 95 }, modifier = Modifier.weight(1f)) {
                            Text("افتراضي", fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = { printScalePercent = (printScalePercent + 5).coerceAtMost(125) }, modifier = Modifier.weight(1f)) {
                            Text("تكبير +", fontSize = 12.sp)
                        }
                    }
                    Text("حجم الطاولات: ${deskScale}%", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { viewModel.updateDeskScale((deskScale - 10).coerceAtLeast(65)) }, modifier = Modifier.weight(1f)) {
                            Text("تصغير الطاولات", fontSize = 11.sp)
                        }
                        OutlinedButton(onClick = { viewModel.updateDeskScale((deskScale + 10).coerceAtMost(150)) }, modifier = Modifier.weight(1f)) {
                            Text("تكبير الطاولات", fontSize = 11.sp)
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            val shareText = buildString {
                                appendLine("📋 مخطط جلوس القسم: ${currentSec?.name ?: ""}")
                                appendLine("حجرة التدريس: $roomNumber · ${currentSec?.year ?: ""}")
                                appendLine("------------------------------")
                                seats.chunked(2).forEachIndexed { deskIdx, pair ->
                                    val s1 = pair.getOrNull(0)?.ifBlank { "شاغر" } ?: "شاغر"
                                    val s2 = pair.getOrNull(1)?.ifBlank { "شاغر" } ?: "شاغر"
                                    appendLine("طاولة ${deskIdx + 1}: [ $s1 | $s2 ]")
                                }
                            }
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, shareText)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "مشاركة مخطط الجلوس"))
                            showPrintDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("مشاركة المخطط كنص")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.printVisualSeatingChart(context, printScalePercent)
                    showPrintDialog = false
                }) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("طباعة / حفظ PDF")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPrintDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Room Config Dialog
    if (showRoomConfigDialog) {
        RoomConfigDialog(
            currentRows = rows,
            currentCols = cols,
            currentDeskSide = deskSide,
            currentRoomNumber = roomNumber,
            onDismiss = { showRoomConfigDialog = false },
            onSave = { newRows, newCols, newSide, newNum ->
                viewModel.updateRoomConfig(newRows, newCols, newSide, newNum)
                showRoomConfigDialog = false
            }
        )
    }

    // Individual Assessment Modal
    if (assessmentStudent != null) {
        val studentName = assessmentStudent!!
        val seatedList = seats.filter { it.isNotBlank() }
        val currentIdx = seatedList.indexOf(studentName)
        val studentScores = currentSecScores[studentName] ?: criteria.map { Math.round(it.max * 0.8 * 10.0) / 10.0 }
        val totalScore = studentScores.take(criteria.size).sum()
        val totalMax = criteria.sumOf { it.max }
        val stepLabel = if (stepSize == 0.25) "0.25" else "0.5"
        var bulkCriterionIndex by remember { mutableIntStateOf(0) }

        fun formatScore(value: Double): String {
            return if (value % 1.0 == 0.0) {
                "%.0f".format(value)
            } else if ((value * 10) % 1.0 == 0.0) {
                "%.1f".format(value)
            } else {
                "%.2f".format(value)
            }
        }

        AlertDialog(
            onDismissRequest = { viewModel.closeAssessmentModal() },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.goToNextStudent(-1) },
                        enabled = currentIdx > 0
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "السابق")
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = studentName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "${currentIdx + 1} من ${seatedList.size} تلاميذ",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = { viewModel.goToNextStudent(1) },
                        enabled = currentIdx < seatedList.size - 1
                    ) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "التالي")
                    }
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Total Score Header
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("مجموع التقويم المستمر:", fontWeight = FontWeight.Bold)
                            Text(
                                text = "${formatScore(totalScore)} / ${formatScore(totalMax)}",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    val scoreOutOf20 = if (Math.abs(totalMax - 20.0) < 0.01) totalScore else (totalScore / totalMax.coerceAtLeast(1.0)) * 20.0
                    val roundedOutOf20 = Math.round(scoreOutOf20.coerceIn(0.0, 20.0) * 100.0) / 100.0

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = EmeraldSuccess.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "✓ تظهر وتتزامن فوراً في دفتر التنقيط:",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess
                            )
                            Text(
                                text = "%.2f / 20.0".format(roundedOutOf20),
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Step Size selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "مقدار الزيادة / النقصان:",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = stepSize == 0.25,
                                onClick = { viewModel.setStepSize(0.25) },
                                label = {
                                    Text(
                                        "0.25 نقطة",
                                        fontSize = 11.sp,
                                        fontWeight = if (stepSize == 0.25) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            )
                            FilterChip(
                                selected = stepSize == 0.5,
                                onClick = { viewModel.setStepSize(0.5) },
                                label = {
                                    Text(
                                        "0.50 نقطة",
                                        fontSize = 11.sp,
                                        fontWeight = if (stepSize == 0.5) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Criteria rows with dynamic steppers
                    criteria.forEachIndexed { i, crit ->
                        val currentScore = studentScores.getOrElse(i) { 0.0 }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${crit.icon} ${crit.name}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "من ${formatScore(crit.max)} نقاط",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedButton(
                                    onClick = { viewModel.updateScore(studentName, i, -stepSize) },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("− $stepLabel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = formatScore(currentScore),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    modifier = Modifier.width(40.dp),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Button(
                                    onClick = { viewModel.updateScore(studentName, i, stepSize) },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("＋ $stepLabel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Bulk Class Assessment Section
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "تعميم نقطة على القسم كله (بمقدار ±$stepLabel):",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                criteria.forEachIndexed { idx, c ->
                                    FilterChip(
                                        selected = bulkCriterionIndex == idx,
                                        onClick = { bulkCriterionIndex = idx },
                                        label = { Text("${c.icon} ${c.name}", fontSize = 10.sp) }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { viewModel.applyBulkScore(bulkCriterionIndex, -stepSize) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("− $stepLabel للقسم", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { viewModel.applyBulkScore(bulkCriterionIndex, stepSize) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("＋ $stepLabel للقسم", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.closeAssessmentModal()
                        viewModel.showToast("تم حفظ تقويم التلميذ بنجاح")
                    }
                ) {
                    Text("تم وحفظ")
                }
            }
        )
    }
}

@Composable
fun TeacherDeskBox(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFFFEF3C7))
            .border(1.5.dp, Color(0xFFFCD34D), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "مكتب الأستاذ",
            color = Color(0xFF78350F),
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
fun DoubleDeskCard(
    deskIndex: Int,
    deskScale: Int = 100,
    seats: List<String>,
    selectedSeatIndex: Int?,
    attendanceMap: Map<String, AttendanceStatus>,
    isMoveMode: Boolean,
    isAttendanceMode: Boolean,
    onSeatClick: (Int) -> Unit
) {
    val seat1Idx = deskIndex * 2
    val seat2Idx = deskIndex * 2 + 1
    val seat1Name = seats.getOrNull(seat1Idx) ?: ""
    val seat2Name = seats.getOrNull(seat2Idx) ?: ""
    val scaleFactor = (deskScale / 100f).coerceIn(0.65f, 1.5f)
    val cardWidth = (220f * scaleFactor).dp

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.width(cardWidth)
    ) {
        Column(modifier = Modifier.padding(6.dp)) {
            // Desk number label
            Text(
                text = "طاولة ${deskIndex + 1}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Seat 1
                SingleSeatBox(
                    name = seat1Name,
                    seatIndex = seat1Idx,
                    isSelected = selectedSeatIndex == seat1Idx,
                    isAbsent = attendanceMap[seat1Name] == AttendanceStatus.ABSENT,
                    isMoveMode = isMoveMode,
                    isAttendanceMode = isAttendanceMode,
                    onClick = { onSeatClick(seat1Idx) },
                    modifier = Modifier.weight(1f)
                )

                // Seat 2
                SingleSeatBox(
                    name = seat2Name,
                    seatIndex = seat2Idx,
                    isSelected = selectedSeatIndex == seat2Idx,
                    isAbsent = attendanceMap[seat2Name] == AttendanceStatus.ABSENT,
                    isMoveMode = isMoveMode,
                    isAttendanceMode = isAttendanceMode,
                    onClick = { onSeatClick(seat2Idx) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun SingleSeatBox(
    name: String,
    seatIndex: Int,
    isSelected: Boolean,
    isAbsent: Boolean,
    isMoveMode: Boolean,
    isAttendanceMode: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isOccupied = name.isNotBlank()
    val bgColor = when {
        isSelected -> MaterialTheme.colorScheme.primaryContainer
        isAbsent -> CoralAbsent.copy(alpha = 0.15f)
        isOccupied -> MaterialTheme.colorScheme.surface
        else -> Color.Transparent
    }

    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        isAbsent -> CoralAbsent
        isOccupied -> MaterialTheme.colorScheme.outlineVariant
        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    }

    Box(
        modifier = modifier
            .height(72.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(
                width = if (isSelected || isAbsent) 2.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        if (isOccupied) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (isAbsent) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(CoralAbsent)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "غائب",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (isMoveMode) {
                    Text(
                        text = if (isSelected) "المحدد" else "انقل",
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                } else if (isAttendanceMode) {
                    Text(
                        text = "حاضر",
                        fontSize = 9.sp,
                        color = EmeraldSuccess
                    )
                }
            }
        } else {
            Text(
                text = "شاغر",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun LegendItem(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = text, style = MaterialTheme.typography.bodySmall)
    }
}
