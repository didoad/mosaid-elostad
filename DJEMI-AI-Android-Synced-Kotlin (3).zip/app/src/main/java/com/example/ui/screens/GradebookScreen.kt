package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.GradebookRow
import com.example.ui.components.EditGradeRowDialog
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.viewmodel.MainViewModel
import com.example.util.PrintHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GradebookScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val currentSec by viewModel.currentSection.collectAsStateWithLifecycle()
    val sections by viewModel.sections.collectAsStateWithLifecycle()
    val gradebookRows by viewModel.currentGradebook.collectAsStateWithLifecycle()
    val currentStudents by viewModel.currentStudents.collectAsStateWithLifecycle()
    val criteria by viewModel.criteria.collectAsStateWithLifecycle()
    val scoresMap by viewModel.studentScoresBySection.collectAsStateWithLifecycle()
    val stepSize by viewModel.stepSize.collectAsStateWithLifecycle()
    val profile by viewModel.teacherProfile.collectAsStateWithLifecycle()

    var sectionDropdownExpanded by remember { mutableStateOf(false) }
    var selectedRowForEdit by remember { mutableStateOf<GradebookRow?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("gradebook_screen")
    ) {
        // Toolbar card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "وثيقة حجز النقاط الرسمية",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "دفتر تنقيط ${currentSec?.name ?: ""}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${currentSec?.subject ?: ""} · ${currentSec?.year ?: ""} · ${gradebookRows.size} تلميذاً",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Section Dropdown
                    ExposedDropdownMenuBox(
                        expanded = sectionDropdownExpanded,
                        onExpandedChange = { sectionDropdownExpanded = !sectionDropdownExpanded }
                    ) {
                        Surface(
                            modifier = Modifier
                                .menuAnchor()
                                .clip(RoundedCornerShape(10.dp))
                                .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))
                                .clickable { sectionDropdownExpanded = true },
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = currentSec?.name ?: "القسم",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = sectionDropdownExpanded)
                            }
                        }
                        ExposedDropdownMenu(
                            expanded = sectionDropdownExpanded,
                            onDismissRequest = { sectionDropdownExpanded = false }
                        ) {
                            sections.forEach { sec ->
                                DropdownMenuItem(
                                    text = { Text(sec.name, fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        viewModel.selectSection(sec.id)
                                        sectionDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Actions row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Sync continuous assessment to gradebook
                    Button(
                        onClick = { viewModel.syncContinuousAssessment() },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("sync_assessment_button")
                    ) {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حفظ التقويم المستمر", fontSize = 12.sp)
                    }

                    // Export Real XLSX
                    Button(
                        onClick = { viewModel.exportGradebookXlsx(context) },
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تصدير XLSX", fontSize = 12.sp)
                    }

                    // Print Gradebook (PDF / Printer)
                    Button(
                        onClick = {
                            currentSec?.let { sec ->
                                PrintHelper.printGradebook(context, sec, profile, gradebookRows)
                            }
                        },
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("طباعة الكشف (PDF)", fontSize = 12.sp)
                    }

                    // Print Blank Gradebook (names only, no marks)
                    OutlinedButton(
                        onClick = {
                            currentSec?.let { sec ->
                                PrintHelper.printBlankGradebook(context, sec, profile, currentStudents)
                            }
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("طباعة فارغة (بدون نقاط)", fontSize = 12.sp)
                    }

                    // Save confirmation
                    OutlinedButton(
                        onClick = { viewModel.showToast("تم حفظ جميع النقاط بنجاح") },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حفظ النقاط", fontSize = 12.sp)
                    }

                    // Export / Share Text
                    OutlinedButton(
                        onClick = {
                            val text = buildString {
                                appendLine("📋 دفتر تنقيط: ${currentSec?.name ?: ""} (${currentSec?.subject ?: ""})")
                                appendLine("السنة: ${currentSec?.year ?: ""} | عدد التلاميذ: ${gradebookRows.size}")
                                appendLine("==========================================")
                                appendLine("م | رقم التعريف | اللقب والاسم | النشاطات | الفرض | الاختبار | المعدل | التقدير")
                                gradebookRows.forEachIndexed { i, r ->
                                    appendLine("${i + 1} | ${r.matricule} | ${r.nom} ${r.prenom} | ${r.activityScore} | ${r.homeworkScore} | ${r.examScore} | %.2f | ${r.autoObservation}".format(r.calculatedAverage))
                                }
                            }
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, text)
                            }
                            context.startActivity(Intent.createChooser(intent, "تصدير دفتر التنقيط"))
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("مشاركة نصية", fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Table Description Banner
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "💡 اضغط على أي تلميذ لتعديل علاماته وحجز النقاط مباشرة.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Gradebook Table inside horizontal scroll
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            val hScrollState = rememberScrollState()

            Column(modifier = Modifier.fillMaxSize()) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(hScrollState)
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                        .padding(vertical = 10.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TableHeaderCell("م", width = 36.dp)
                    TableHeaderCell("رقم التعريف", width = 95.dp)
                    TableHeaderCell("اللقب والاسم", width = 160.dp)
                    TableHeaderCell("تاريخ الميلاد", width = 90.dp)
                    TableHeaderCell("النشاطات /20", width = 90.dp)
                    TableHeaderCell("الفرض /20", width = 80.dp)
                    TableHeaderCell("الاختبار /20", width = 85.dp)
                    TableHeaderCell("المعدل", width = 75.dp)
                    TableHeaderCell("التقدير", width = 90.dp)
                }

                // Table Rows
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    itemsIndexed(gradebookRows) { index, row ->
                        val isEven = index % 2 == 0
                        val rowBg = if (isEven) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(hScrollState)
                                .background(rowBg)
                                .clickable { selectedRowForEdit = row }
                                .padding(vertical = 9.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TableCell("${index + 1}", width = 36.dp, isBold = true)
                            TableCell(row.matricule, width = 95.dp)
                            TableCell("${row.nom} ${row.prenom}", width = 160.dp, isBold = true, isPrimary = true)
                            TableCell(row.dateNaissance, width = 90.dp)
                            TableCell("%.1f".format(row.activityScore), width = 90.dp, isBold = true)
                            TableCell("%.1f".format(row.homeworkScore), width = 80.dp)
                            TableCell("%.1f".format(row.examScore), width = 85.dp)
                            TableCell("%.2f".format(row.calculatedAverage), width = 75.dp, isBold = true, isPrimary = true)
                            TableCell(row.autoObservation, width = 90.dp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Official note footer
        Text(
            text = "▥ مطابق لدفتر الحجز الرسمي لوزارة التربية الوطنية: رقم التعريف، اللقب، الاسم، تاريخ الميلاد، تقويم النشاطات، الفرض، الاختبار والتقديرات.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 10.sp
        )
    }

    // Edit Marks Dialog
    selectedRowForEdit?.let { row ->
        val matchedStudent = currentStudents.find { it.id == row.studentId }
        val fullName = matchedStudent?.fullName ?: "${row.nom} ${row.prenom}".trim()
        val secId = currentSec?.id ?: 1L
        val studentCriteriaScores = scoresMap[secId]?.get(fullName) ?: criteria.map { it.max * 0.8 }

        EditGradeRowDialog(
            row = row,
            criteria = criteria,
            studentCriteriaScores = studentCriteriaScores,
            stepSize = stepSize,
            onCriteriaScoreChange = { critIdx, delta ->
                viewModel.updateScore(fullName, critIdx, delta)
            },
            onDismiss = { selectedRowForEdit = null },
            onSave = { updated ->
                viewModel.updateGradebookRow(updated)
                selectedRowForEdit = null
            }
        )
    }
}

@Composable
fun TableHeaderCell(text: String, width: androidx.compose.ui.unit.Dp) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        textAlign = TextAlign.Center,
        modifier = Modifier.width(width)
    )
}

@Composable
fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    isBold: Boolean = false,
    isPrimary: Boolean = false
) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
        color = if (isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
        modifier = Modifier.width(width)
    )
}
