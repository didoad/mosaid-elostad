package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalContext
import com.example.util.ExcelHelper
import com.example.util.ParsedStudent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GradebookRow
import com.example.data.model.LevelInfo
import com.example.data.model.Section
import com.example.data.model.Student
import com.example.data.model.TeacherProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSectionDialog(
    levels: List<LevelInfo>,
    onDismiss: () -> Unit,
    onConfirm: (name: String, level: String, year: String, students: List<com.example.util.ParsedStudent>) -> Unit,
    onDownloadTemplate: () -> Unit = {}
) {
    val context = LocalContext.current
    var sectionName by remember { mutableStateOf("") }
    var selectedLevel by remember { mutableStateOf(levels.firstOrNull()?.label ?: "الأولى متوسط") }
    var year by remember { mutableStateOf("2026 / 2027") }
    var expanded by remember { mutableStateOf(false) }

    val pendingStudents = remember { mutableStateListOf<com.example.util.ParsedStudent>() }
    var newStudentDraft by remember { mutableStateOf("") }
    var showPasteDialog by remember { mutableStateOf(false) }
    var pasteTextDraft by remember { mutableStateOf("") }
    var importStatusMsg by remember { mutableStateOf<String?>(null) }

    // File picker launcher for XLSX / CSV / Excel files
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream != null) {
                    val parsed = ExcelHelper.parseStream(inputStream)
                    inputStream.close()
                    if (parsed.isNotEmpty()) {
                        pendingStudents.clear()
                        pendingStudents.addAll(parsed)
                        val detectedSec = parsed.firstOrNull { it.sectionName.isNotBlank() }?.sectionName
                        if (!detectedSec.isNullOrBlank() && sectionName.isBlank()) {
                            sectionName = detectedSec
                        }
                        importStatusMsg = "✓ تم استيراد ${parsed.size} تلميذاً من ملف الرقمنة / Excel بنجاح"
                    } else {
                        importStatusMsg = "لم يتم العثور على أسماء تلاميذ في الملف المحدد"
                    }
                }
            } catch (e: Exception) {
                importStatusMsg = "تعذر قراءة الملف: ${e.localizedMessage}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "إضافة قسم جديد",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ) {
                    Text(
                        text = "XLSX / الرقمنة",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
            ) {
                Text(
                    text = "حدد بيانات القسم ويمكنك استيراد قائمة التلاميذ مباشرة من ملف الرقمنة أو Excel:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedLevel,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("المستوى الدراسي") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        levels.forEach { lvl ->
                            DropdownMenuItem(
                                text = { Text(lvl.label) },
                                onClick = {
                                    selectedLevel = lvl.label
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = sectionName,
                    onValueChange = { sectionName = it },
                    label = { Text("اسم القسم (مثال: 1م4 أو 3م5)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_section_name_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = year,
                    onValueChange = { year = it },
                    label = { Text("السنة الدراسية") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Excel & Digitization Actions Row
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "استيراد وتصدير قائمة القسم:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { filePickerLauncher.launch("*/*") },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Text("استيراد XLSX / الرقمنة", fontSize = 11.sp, maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { showPasteDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Text("لصق الأسماء", fontSize = 11.sp, maxLines = 1)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedButton(
                                onClick = onDownloadTemplate,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Text("تنزيل نموذج XLSX", fontSize = 11.sp, maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = {
                                    if (pendingStudents.isNotEmpty()) {
                                        val bytes = ExcelHelper.createStudentsListXlsx(sectionName.ifBlank { "القسم_الجديد" }, pendingStudents.toList())
                                        ExcelHelper.shareFile(context, "قائمة_${sectionName.ifBlank { "القسم_الجديد" }}.xlsx", bytes, "تصدير قائمة التلاميذ")
                                    }
                                },
                                enabled = pendingStudents.isNotEmpty(),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Text("تصدير XLSX", fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }

                importStatusMsg?.let { msg ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (msg.startsWith("✓")) Color(0xFF10B981) else MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "التلاميذ المجهزون (${pendingStudents.size} تلميذ)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (pendingStudents.isNotEmpty()) {
                        TextButton(onClick = { pendingStudents.clear() }) {
                            Text("مسح القائمة", color = Color.Red, fontSize = 11.sp)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newStudentDraft,
                        onValueChange = { newStudentDraft = it },
                        placeholder = { Text("أضف تلميذاً يدوياً...") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            val clean = newStudentDraft.trim()
                            if (clean.isNotBlank() && pendingStudents.none { it.fullName == clean }) {
                                pendingStudents.add(
                                    com.example.util.ParsedStudent(
                                        fullName = clean,
                                        matricule = "26%04d".format(pendingStudents.size + 1),
                                        birthDate = "15/05/2012"
                                    )
                                )
                                newStudentDraft = ""
                            }
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "إضافة")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(modifier = Modifier.heightIn(max = 130.dp)) {
                    itemsIndexed(pendingStudents) { idx, st ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "${idx + 1}. ${st.fullName}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                if (st.matricule.isNotBlank()) {
                                    Text(text = "رقم التعريف: ${st.matricule} · الميلاد: ${st.birthDate}", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            IconButton(
                                onClick = { pendingStudents.removeAt(idx) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (sectionName.isNotBlank()) {
                        onConfirm(sectionName.trim(), selectedLevel, year.trim(), pendingStudents.toList())
                    }
                },
                enabled = sectionName.isNotBlank(),
                modifier = Modifier.testTag("save_section_button")
            ) {
                Text("حفظ القسم والتلاميذ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )

    if (showPasteDialog) {
        AlertDialog(
            onDismissRequest = { showPasteDialog = false },
            title = { Text("لصق قائمة التلاميذ", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "الصق قائمة الأسماء هنا (سطر لكل تلميذ أو مفصولة بفواصل/أعمدة من Excel):",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pasteTextDraft,
                        onValueChange = { pasteTextDraft = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        shape = RoundedCornerShape(10.dp),
                        placeholder = { Text("أحمد بن علي\nفاطمة الزهراء بوجمعة\nمحمد الأمين بلقاسم...") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsed = ExcelHelper.parsePastedText(pasteTextDraft)
                        if (parsed.isNotEmpty()) {
                            pendingStudents.addAll(parsed)
                            importStatusMsg = "✓ تم استيراد ${parsed.size} تلميذاً من النص الملصق"
                        }
                        showPasteDialog = false
                        pasteTextDraft = ""
                    }
                ) {
                    Text("استخراج الأسماء")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPasteDialog = false }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
fun EditProfileDialog(
    profile: TeacherProfile,
    onDismiss: () -> Unit,
    onSave: (TeacherProfile) -> Unit
) {
    var schoolName by remember { mutableStateOf(profile.schoolName) }
    var teacher by remember { mutableStateOf(profile.teacher) }
    var year by remember { mutableStateOf(profile.year) }
    var subject by remember { mutableStateOf(profile.subject) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "بطاقة الأستاذ والمعلومات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = schoolName,
                    onValueChange = { schoolName = it },
                    label = { Text("اسم المتوسطة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = teacher,
                    onValueChange = { teacher = it },
                    label = { Text("اسم الأستاذ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("مادة التدريس") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = year,
                    onValueChange = { year = it },
                    label = { Text("السنة الدراسية") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(TeacherProfile(schoolName = schoolName, teacher = teacher, year = year, subject = subject))
                }
            ) {
                Text("حفظ البيانات")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun AddStudentDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String) -> Unit
) {
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "إضافة تلميذ جديد", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "أدخل اسم التلميذ ليظهر في القائمة ومخطط الجلوس ودفتر التنقيط:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم التلميذ (مثال: ياسين بلقاسم)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("student_name_input"),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) onAdd(name.trim())
                },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("submit_student_button")
            ) {
                Text("إضافة التلميذ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun StudentsManagerDialog(
    students: List<Student>,
    onDismiss: () -> Unit,
    onRename: (id: Long, newName: String) -> Unit,
    onDelete: (id: Long) -> Unit,
    onClearAll: () -> Unit
) {
    var editingStudentId by remember { mutableStateOf<Long?>(null) }
    var editNameDraft by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("إدارة تلاميذ القسم", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("(${students.size} تلميذ)", style = MaterialTheme.typography.bodySmall)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                if (students.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("لا يوجد تلاميذ في هذا القسم", style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    LazyColumn {
                        itemsIndexed(students) { index, s ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    if (editingStudentId == s.id) {
                                        OutlinedTextField(
                                            value = editNameDraft,
                                            onValueChange = { editNameDraft = it },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        IconButton(onClick = {
                                            if (editNameDraft.isNotBlank()) {
                                                onRename(s.id, editNameDraft.trim())
                                                editingStudentId = null
                                            }
                                        }) {
                                            Text("✓", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        }
                                    } else {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Text("${index + 1}. ", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                            Text(s.fullName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                        }
                                        Row {
                                            IconButton(
                                                onClick = {
                                                    editingStudentId = s.id
                                                    editNameDraft = s.fullName
                                                },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Edit, contentDescription = "تعديل", modifier = Modifier.size(16.dp))
                                            }
                                            IconButton(
                                                onClick = { onDelete(s.id) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (students.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = onClearAll,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("مسح جميع تلاميذ القسم")
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

@Composable
fun RoomConfigDialog(
    currentRows: Int,
    currentCols: Int,
    currentDeskSide: String,
    currentRoomNumber: String,
    onDismiss: () -> Unit,
    onSave: (rows: Int, cols: Int, deskSide: String, roomNumber: String) -> Unit
) {
    var rows by remember { mutableStateOf(currentRows) }
    var cols by remember { mutableStateOf(currentCols) }
    var deskSide by remember { mutableStateOf(currentDeskSide) }
    var roomNumber by remember { mutableStateOf(currentRoomNumber) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "إعدادات حجرة التدريس", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "حدد عدد الصفوف والأعمدة للطاولات المزدوجة وموقع مكتب الأستاذ:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("عدد الصفوف: $rows", fontWeight = FontWeight.Bold)
                    Row {
                        OutlinedButton(onClick = { if (rows > 1) rows-- }, shape = RoundedCornerShape(8.dp)) { Text("−") }
                        Spacer(modifier = Modifier.width(6.dp))
                        OutlinedButton(onClick = { if (rows < 8) rows++ }, shape = RoundedCornerShape(8.dp)) { Text("＋") }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("عدد الأعمدة: $cols", fontWeight = FontWeight.Bold)
                    Row {
                        OutlinedButton(onClick = { if (cols > 2) cols-- }, shape = RoundedCornerShape(8.dp)) { Text("−") }
                        Spacer(modifier = Modifier.width(6.dp))
                        OutlinedButton(onClick = { if (cols < 6) cols++ }, shape = RoundedCornerShape(8.dp)) { Text("＋") }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("موقع مكتب الأستاذ:", fontWeight = FontWeight.Bold)
                    Row {
                        Button(
                            onClick = { deskSide = "right" },
                            colors = if (deskSide == "right") ButtonDefaults.buttonColors() else ButtonDefaults.outlinedButtonColors()
                        ) {
                            Text("اليمين")
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Button(
                            onClick = { deskSide = "left" },
                            colors = if (deskSide == "left") ButtonDefaults.buttonColors() else ButtonDefaults.outlinedButtonColors()
                        ) {
                            Text("اليسار")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = roomNumber,
                    onValueChange = { roomNumber = it },
                    label = { Text("رقم حجرة التدريس") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "السعة الإجمالية: ${rows * cols * 2} مقعداً (${rows * cols} طاولات مزدوجة)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(rows, cols, deskSide, roomNumber) }) {
                Text("تطبيق وتحديث")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun EditGradeRowDialog(
    row: GradebookRow,
    criteria: List<com.example.data.model.AssessmentCriterion> = emptyList(),
    studentCriteriaScores: List<Double> = emptyList(),
    stepSize: Double = 0.5,
    onCriteriaScoreChange: ((criterionIndex: Int, delta: Double) -> Unit)? = null,
    onDismiss: () -> Unit,
    onSave: (GradebookRow) -> Unit
) {
    val totalCriteriaMax = criteria.sumOf { it.max }.coerceAtLeast(1.0)
    val localScores = remember(studentCriteriaScores, criteria) {
        val list = studentCriteriaScores.toMutableList()
        while (list.size < criteria.size) {
            val critMax = criteria.getOrNull(list.size)?.max ?: 5.0
            list.add(Math.round(critMax * 0.8 * 10.0) / 10.0)
        }
        androidx.compose.runtime.mutableStateListOf(*list.toTypedArray())
    }

    var activity by remember { mutableStateOf("%.2f".format(row.activityScore)) }
    var homework by remember { mutableStateOf(row.homeworkScore.toString()) }
    var exam by remember { mutableStateOf(row.examScore.toString()) }
    var obs by remember { mutableStateOf(row.observation) }

    fun recomputeActivityFromCriteria() {
        val sum = localScores.take(criteria.size).sum()
        val calculatedAct = Math.round(((sum / totalCriteriaMax) * 20.0).coerceIn(0.0, 20.0) * 100.0) / 100.0
        activity = "%.2f".format(calculatedAct)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "حجز نقاط: ${row.nom} ${row.prenom}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "رقم التعريف: ${row.matricule} · تاريخ الميلاد: ${row.dateNaissance}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp)
                    .verticalScroll(androidx.compose.foundation.rememberScrollState())
            ) {
                // Interactive Criteria Section if available
                if (criteria.isNotEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "معايير التقويم الفردي (المستمر):",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primary
                                ) {
                                    Text(
                                        text = "خطوة: $stepSize",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            criteria.forEachIndexed { i, crit ->
                                val curScore = localScores.getOrElse(i) { 0.0 }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${crit.icon} ${crit.name}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "من ${crit.max.toInt()} نقاط",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        OutlinedButton(
                                            onClick = {
                                                val n = (curScore - stepSize).coerceIn(0.0, crit.max)
                                                localScores[i] = Math.round(n * 100.0) / 100.0
                                                recomputeActivityFromCriteria()
                                                onCriteriaScoreChange?.invoke(i, -stepSize)
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Text("−", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "%.2f".format(curScore).trimEnd('0').trimEnd('.'),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            modifier = Modifier.width(36.dp),
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))

                                        Button(
                                            onClick = {
                                                val n = (curScore + stepSize).coerceIn(0.0, crit.max)
                                                localScores[i] = Math.round(n * 100.0) / 100.0
                                                recomputeActivityFromCriteria()
                                                onCriteriaScoreChange?.invoke(i, stepSize)
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Text("＋", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                OutlinedTextField(
                    value = activity,
                    onValueChange = { activity = it },
                    label = { Text("تقويم النشاطات / 20 (المستمر)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = homework,
                    onValueChange = { homework = it },
                    label = { Text("الفرض / 20") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = exam,
                    onValueChange = { exam = it },
                    label = { Text("الاختبار / 20") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = obs,
                    onValueChange = { obs = it },
                    label = { Text("ملاحظة أو تقدير خاص (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Live Average Preview
                val actVal = activity.toDoubleOrNull() ?: row.activityScore
                val hwVal = homework.toDoubleOrNull() ?: row.homeworkScore
                val exVal = exam.toDoubleOrNull() ?: row.examScore
                val liveTotal = actVal + hwVal + (exVal * 2)
                val liveAvg = (liveTotal / 4.0).coerceIn(0.0, 20.0)

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("المعدل المحسوب للثلاثي:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        Text(
                            text = "%.2f / 20.0".format(liveAvg),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val act = activity.toDoubleOrNull() ?: row.activityScore
                val hw = homework.toDoubleOrNull() ?: row.homeworkScore
                val ex = exam.toDoubleOrNull() ?: row.examScore
                onSave(
                    row.copy(
                        activityScore = act.coerceIn(0.0, 20.0),
                        homeworkScore = hw.coerceIn(0.0, 20.0),
                        examScore = ex.coerceIn(0.0, 20.0),
                        observation = obs
                    )
                )
            }) {
                Text("حفظ النقاط")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun CriterionEditorDialog(
    initialCriterion: com.example.data.model.AssessmentCriterion? = null,
    onDismiss: () -> Unit,
    onSave: (name: String, max: Double, icon: String) -> Unit
) {
    var name by remember { mutableStateOf(initialCriterion?.name ?: "") }
    var maxStr by remember { mutableStateOf(initialCriterion?.max?.toInt()?.toString() ?: "5") }
    var selectedIcon by remember { mutableStateOf(initialCriterion?.icon ?: "★") }

    val iconOptions = listOf("⏱", "✋", "📓", "👥", "🏆", "💡", "🔬", "📖", "🎨", "✍️", "🎯", "⭐")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialCriterion == null) "إضافة معيار تقويم جديد" else "تعديل معيار التقويم",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "حدد اسم المعيار والنقطة الكلية له:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المعيار (مثال: حفظ النصوص أو التجارب)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = maxStr,
                    onValueChange = { maxStr = it },
                    label = { Text("النقطة الكلية القصوى (مثال: 5 أو 4)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "اختر أيقونة أو رمز المعيار:",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    iconOptions.take(6).forEach { ic ->
                        val isSelected = selectedIcon == ic
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                .border(
                                    width = if (isSelected) 2.dp else 0.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { selectedIcon = ic },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(ic, fontSize = 16.sp)
                        }
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    iconOptions.drop(6).forEach { ic ->
                        val isSelected = selectedIcon == ic
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                .border(
                                    width = if (isSelected) 2.dp else 0.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { selectedIcon = ic },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(ic, fontSize = 16.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val maxVal = maxStr.toDoubleOrNull() ?: 5.0
                    if (name.isNotBlank()) {
                        onSave(name.trim(), maxVal, selectedIcon)
                    }
                },
                enabled = name.isNotBlank()
            ) {
                Text(if (initialCriterion == null) "إضافة المعيار" else "حفظ التعديل")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditSectionDialog(
    section: Section,
    levels: List<LevelInfo>,
    onDismiss: () -> Unit,
    onSave: (Section) -> Unit
) {
    var name by remember { mutableStateOf(section.name) }
    var selectedLevel by remember { mutableStateOf(section.level) }
    var year by remember { mutableStateOf(section.year) }
    var roomNumber by remember { mutableStateOf(section.roomNumber) }
    var expanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "تعديل بيانات القسم",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "يمكنك تعديل اسم القسم، المستوى التعليمي، السنة الدراسية ورقم الحجرة:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedLevel,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("المستوى الدراسي") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        levels.forEach { lvl ->
                            DropdownMenuItem(
                                text = { Text(lvl.label) },
                                onClick = {
                                    selectedLevel = lvl.label
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم القسم (مثال: 1م1 أو 3م4)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_section_name_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = year,
                    onValueChange = { year = it },
                    label = { Text("السنة الدراسية") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = roomNumber,
                    onValueChange = { roomNumber = it },
                    label = { Text("رقم الحجرة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val updatedCode = when (selectedLevel) {
                            "الأولى متوسط" -> "1AM"
                            "الثانية متوسط" -> "2AM"
                            "الثالثة متوسط" -> "3AM"
                            "الرابعة متوسط" -> "4AM"
                            else -> "AM"
                        } + "-${section.id}"
                        onSave(
                            section.copy(
                                name = name.trim(),
                                level = selectedLevel,
                                code = updatedCode,
                                year = year.trim(),
                                roomNumber = roomNumber.trim()
                            )
                        )
                    }
                },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("save_edit_section_button")
            ) {
                Text("حفظ التعديل")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun DeleteSectionDialog(
    section: Section,
    totalSectionsCount: Int,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "حذف القسم «${section.name}»",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error
            )
        },
        text = {
            Column {
                if (totalSectionsCount <= 1) {
                    Text(
                        text = "لا يمكن حذف هذا القسم لأنه القسم الوحيد المسند في التطبيق. يجب أن يتوفر قسم واحد على الأقل.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                } else {
                    Text(
                        text = "هل أنت متأكد من حذف قسم «${section.name}» (${section.level})؟\n\nتنبيه: سيتم حذف جميع التلاميذ المرتبطين بهذا القسم ونقاط تقويمهم ومخطط جلوسهم نهائياً.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        },
        confirmButton = {
            if (totalSectionsCount > 1) {
                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_section_button")
                ) {
                    Text("نعم، حذف القسم")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (totalSectionsCount <= 1) "حسناً" else "إلغاء")
            }
        }
    )
}

@Composable
fun ImportSectionStudentsDialog(
    sectionName: String,
    onDismiss: () -> Unit,
    onImportParsed: (List<com.example.util.ParsedStudent>) -> Unit,
    onDownloadTemplate: () -> Unit
) {
    val context = LocalContext.current
    val pendingStudents = remember { mutableStateListOf<com.example.util.ParsedStudent>() }
    var pasteTextDraft by remember { mutableStateOf("") }
    var isPasteMode by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream != null) {
                    val parsed = ExcelHelper.parseStream(inputStream)
                    inputStream.close()
                    if (parsed.isNotEmpty()) {
                        pendingStudents.clear()
                        pendingStudents.addAll(parsed)
                        statusMessage = "✓ تم العثور على ${parsed.size} تلميذاً في الملف"
                    } else {
                        statusMessage = "لم يتم العثور على أسماء في الملف"
                    }
                }
            } catch (e: Exception) {
                statusMessage = "خطأ أثناء قراءة الملف: ${e.localizedMessage}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "استيراد تلاميذ إلى قسم $sectionName",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
            ) {
                Text(
                    text = "اختر طريقة استيراد التلاميذ إلى قسم $sectionName:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { filePickerLauncher.launch("*/*") },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("ملف Excel / الرقمنة", fontSize = 11.sp, maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = { isPasteMode = !isPasteMode },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isPasteMode) "إخفاء النص" else "لصق قائمة", fontSize = 11.sp, maxLines = 1)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                OutlinedButton(
                    onClick = onDownloadTemplate,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("تنزيل نموذج Excel فارغ", fontSize = 11.sp)
                }

                if (isPasteMode) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pasteTextDraft,
                        onValueChange = { pasteTextDraft = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                        shape = RoundedCornerShape(10.dp),
                        placeholder = { Text("الصق أسماء التلاميذ هنا...") }
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Button(
                        onClick = {
                            val parsed = ExcelHelper.parsePastedText(pasteTextDraft)
                            if (parsed.isNotEmpty()) {
                                pendingStudents.addAll(parsed)
                                statusMessage = "✓ تم استخراج ${parsed.size} اسماً من النص"
                                pasteTextDraft = ""
                            }
                        },
                        modifier = Modifier.align(Alignment.End),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("إضافة الأسماء الملصقة", fontSize = 11.sp)
                    }
                }

                statusMessage?.let { msg ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (msg.startsWith("✓")) Color(0xFF10B981) else MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (pendingStudents.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "التلاميذ المكتشفون (${pendingStudents.size} تلميذ):",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyColumn(modifier = Modifier.heightIn(max = 140.dp)) {
                        itemsIndexed(pendingStudents) { idx, st ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${idx + 1}. ${st.fullName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                IconButton(
                                    onClick = { pendingStudents.removeAt(idx) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (pendingStudents.isNotEmpty()) {
                        onImportParsed(pendingStudents.toList())
                    }
                },
                enabled = pendingStudents.isNotEmpty(),
                modifier = Modifier.testTag("confirm_import_students_button")
            ) {
                Text("تأكيد استيراد (${pendingStudents.size}) تلميذاً")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun BlankPrintDialog(
    sectionName: String,
    onDismiss: () -> Unit,
    onPrintBlankAssessmentGrid: () -> Unit,
    onPrintBlankGradebook: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Print, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("طباعة وثائق فارغة (للتنقيط اليدوي)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "اختر نوع الوثيقة لطباعتها مع أسماء تلاميذ قسم $sectionName وخانات فارغة لتعبئة النقاط يدوياً:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Option 1: شبكة التقويم المستمر فارغة
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onPrintBlankAssessmentGrid() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Assessment, contentDescription = null, tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "شبكة معايير التقويم المستمر",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "أسماء التلاميذ وأعمدة معايير الأنشطة فارغة للتنقيط اليدوي المباشر أثناء الحصة",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Option 2: دفتر التنقيط الرسمي فارغ
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onPrintBlankGradebook() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Description, contentDescription = null, tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "دفتر التنقيط وكشف النقاط الرسمي",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "أسماء التلاميذ وأرقام التعريف وخانات فارغة للتقويم المستمر، الفرض، الاختبار والمعدل",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

