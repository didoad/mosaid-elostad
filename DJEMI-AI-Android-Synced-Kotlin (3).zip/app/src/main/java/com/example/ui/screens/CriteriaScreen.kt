package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AssessmentCriterion
import com.example.ui.components.BlankPrintDialog
import com.example.ui.components.CriterionEditorDialog
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.MainViewModel
import com.example.util.PrintHelper

@Composable
fun CriteriaScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val profile by viewModel.teacherProfile.collectAsStateWithLifecycle()
    val currentSec by viewModel.currentSection.collectAsStateWithLifecycle()
    val criteria by viewModel.criteria.collectAsStateWithLifecycle()
    val stepSize by viewModel.stepSize.collectAsStateWithLifecycle()
    val currentStudents by viewModel.currentStudents.collectAsStateWithLifecycle()
    val scoresMap by viewModel.studentScoresBySection.collectAsStateWithLifecycle()
    val gradebookRows by viewModel.currentGradebook.collectAsStateWithLifecycle()

    var selectedBulkCritIndex by remember { mutableIntStateOf(0) }
    var selectedStudentIndex by remember { mutableIntStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showBlankPrintDialog by remember { mutableStateOf(false) }
    var editingCriterion by remember { mutableStateOf<AssessmentCriterion?>(null) }

    val totalMax = criteria.sumOf { it.max }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("criteria_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "التقويم المستمر الشامل",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "معايير التقويم والتنقيط",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "المجموع: %.1f نقطة".format(totalMax),
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Text(
                        text = "القسم النشط: ${currentSec?.name ?: ""} · عدد المعايير: ${criteria.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Step Size Controller (معدل الزيادة والنقصان: 0.5 أو 0.25)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "مقدار الزيادة والنقصان:",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "يُطبق على التقويم الفردي والجماعي",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 10.sp
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = stepSize == 0.5,
                                    onClick = { viewModel.setStepSize(0.5) },
                                    label = { Text("0.5 نقطة", fontWeight = FontWeight.Bold) },
                                    leadingIcon = if (stepSize == 0.5) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                    } else null
                                )
                                FilterChip(
                                    selected = stepSize == 0.25,
                                    onClick = { viewModel.setStepSize(0.25) },
                                    label = { Text("0.25 نقطة", fontWeight = FontWeight.Bold) },
                                    leadingIcon = if (stepSize == 0.25) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                    } else null
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Actions Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showBlankPrintDialog = true },
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("طباعة فارغة (للتنقيط اليدوي)", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { showAddDialog = true },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة معيار", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.syncContinuousAssessment() },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("نسخ للدفتر", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.resetDefaultCriteria() },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "استعادة الافتراضي", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("افتراضي", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // List of Criteria with Edit & Delete actions
        itemsIndexed(criteria) { index, crit ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(crit.icon, fontSize = 18.sp)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = crit.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                val maxLabel = if (crit.max % 1.0 == 0.0) crit.max.toInt().toString() else "%.2f".format(crit.max).trimEnd('0').trimEnd('.')
                                Text(
                                    text = "النقطة الكلية القصوى: $maxLabel نقاط",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { editingCriterion = crit },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "تعديل المعيار", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            }
                            if (criteria.size > 1) {
                                IconButton(
                                    onClick = { viewModel.deleteCriterion(crit.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف المعيار", tint = Color.Red, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { (crit.score / crit.max).coerceIn(0.0, 1.0).toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        }

        // Bulk Booster Tool Card with chosen stepSize
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "التقويم الجماعي للقسم كله",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "خطوة: $stepSize",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "اختر المعيار ثم أضف أو انقص بمقدار $stepSize نقطة لجميع تلاميذ القسم دفعة واحدة:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        criteria.forEachIndexed { idx, c ->
                            FilterChip(
                                selected = selectedBulkCritIndex == idx,
                                onClick = { selectedBulkCritIndex = idx },
                                label = { Text("${c.icon} ${c.name}", fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.applyBulkScore(selectedBulkCritIndex, -stepSize) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("− $stepSize للقسم", fontSize = 12.sp)
                        }
                        Button(
                            onClick = { viewModel.applyBulkScore(selectedBulkCritIndex, stepSize) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("＋ $stepSize للقسم", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Individual Assessment Card (التقويم الفردي للتلاميذ ومزامنته مع دفتر التنقيط)
        item {
            val secId = currentSec?.id ?: 1L
            val secScores = scoresMap[secId] ?: emptyMap()
            val validStudentIndex = if (currentStudents.isNotEmpty()) selectedStudentIndex.coerceIn(0, currentStudents.size - 1) else 0
            val activeStudent = currentStudents.getOrNull(validStudentIndex)

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "مزامنة لحظية مع دفتر التنقيط",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "التقويم الفردي لتلاميذ القسم",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = EmeraldSuccess.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "خطوة: $stepSize",
                                color = EmeraldSuccess,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Text(
                        text = "اختر أي تلميذ لتعديل علاماته في معايير التقويم؛ النتيجة تُسجّل وتظهر فوراً في خانة النشاطات بدفتر التنقيط والتقويم:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (currentStudents.isEmpty()) {
                        Text(
                            text = "لا يوجد تلاميذ مسجلين في هذا القسم.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        // Student selector chips
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            currentStudents.forEachIndexed { idx, st ->
                                FilterChip(
                                    selected = validStudentIndex == idx,
                                    onClick = { selectedStudentIndex = idx },
                                    label = { Text("${idx + 1}. ${st.fullName}", fontSize = 11.sp, fontWeight = if (validStudentIndex == idx) FontWeight.Bold else FontWeight.Normal) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        activeStudent?.let { st ->
                            val stName = st.fullName
                            val studentCriteriaScores = secScores[stName] ?: criteria.map { Math.round(it.max * 0.8 * 10.0) / 10.0 }
                            val totalSum = studentCriteriaScores.take(criteria.size).sum()
                            val scoreOutOf20 = if (Math.abs(totalMax - 20.0) < 0.01) totalSum else (totalSum / totalMax.coerceAtLeast(1.0)) * 20.0
                            val roundedOutOf20 = Math.round(scoreOutOf20.coerceIn(0.0, 20.0) * 100.0) / 100.0
                            val matchedGbRow = gradebookRows.find { it.studentId == st.id || "${it.nom} ${it.prenom}".trim() == stName.trim() }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    // Student header & navigation
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(
                                            onClick = { if (validStudentIndex > 0) selectedStudentIndex = validStudentIndex - 1 },
                                            enabled = validStudentIndex > 0,
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.ArrowBack, contentDescription = "التلميذ السابق", modifier = Modifier.size(18.dp))
                                        }

                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = stName,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "رقم التعريف: ${st.matricule} · (${validStudentIndex + 1} من ${currentStudents.size})",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 10.sp
                                            )
                                        }

                                        IconButton(
                                            onClick = { if (validStudentIndex < currentStudents.size - 1) selectedStudentIndex = validStudentIndex + 1 },
                                            enabled = validStudentIndex < currentStudents.size - 1,
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.ArrowForward, contentDescription = "التلميذ التالي", modifier = Modifier.size(18.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Live Gradebook badge
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = EmeraldSuccess.copy(alpha = 0.15f),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "✓ تظهر وتتزامن فوراً في دفتر التنقيط:",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.Bold,
                                                color = EmeraldSuccess
                                            )
                                            Text(
                                                text = "%.2f / 20.0".format(roundedOutOf20),
                                                fontWeight = FontWeight.Bold,
                                                color = EmeraldSuccess,
                                                fontSize = 13.sp
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Criteria Stepper Rows
                                    criteria.forEachIndexed { cIdx, crit ->
                                        val curScore = studentCriteriaScores.getOrElse(cIdx) { 0.0 }
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "${crit.icon} ${crit.name}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                val maxFmt = if (crit.max % 1.0 == 0.0) crit.max.toInt().toString() else "%.2f".format(crit.max).trimEnd('0').trimEnd('.')
                                                Text(
                                                    text = "من $maxFmt نقاط",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                OutlinedButton(
                                                    onClick = { viewModel.updateScore(stName, cIdx, -stepSize) },
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(30.dp)
                                                ) {
                                                    Text("− $stepSize", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "%.2f".format(curScore).trimEnd('0').trimEnd('.'),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    modifier = Modifier.width(38.dp),
                                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Button(
                                                    onClick = { viewModel.updateScore(stName, cIdx, stepSize) },
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(30.dp)
                                                ) {
                                                    Text("＋ $stepSize", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }

                                    matchedGbRow?.let { row ->
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Surface(
                                            color = MaterialTheme.colorScheme.surface,
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "الفرض: ${row.homeworkScore} | الاختبار: ${row.examScore}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontSize = 11.sp
                                                )
                                                Text(
                                                    text = "معدل الثلاثي: %.2f (${row.autoObservation})".format(row.calculatedAverage),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Add Criterion Dialog
    if (showAddDialog) {
        CriterionEditorDialog(
            initialCriterion = null,
            onDismiss = { showAddDialog = false },
            onSave = { name, max, icon ->
                viewModel.addCriterion(name, max, icon)
                showAddDialog = false
            }
        )
    }

    // Edit Criterion Dialog
    editingCriterion?.let { crit ->
        CriterionEditorDialog(
            initialCriterion = crit,
            onDismiss = { editingCriterion = null },
            onSave = { name, max, icon ->
                viewModel.updateCriterion(crit.id, name, max, icon)
                editingCriterion = null
            }
        )
    }

    // Blank Print Dialog for Assessment & Gradebook
    if (showBlankPrintDialog) {
        currentSec?.let { sec ->
            BlankPrintDialog(
                sectionName = sec.name,
                onDismiss = { showBlankPrintDialog = false },
                onPrintBlankAssessmentGrid = {
                    PrintHelper.printBlankAssessmentGrid(
                        context = context,
                        section = sec,
                        teacherProfile = profile,
                        criteria = criteria,
                        students = currentStudents
                    )
                    showBlankPrintDialog = false
                },
                onPrintBlankGradebook = {
                    PrintHelper.printBlankGradebook(
                        context = context,
                        section = sec,
                        teacherProfile = profile,
                        students = currentStudents
                    )
                    showBlankPrintDialog = false
                }
            )
        }
    }
}
