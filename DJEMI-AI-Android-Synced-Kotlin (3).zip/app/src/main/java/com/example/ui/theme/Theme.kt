package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun DjemiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    accentColor: Color = PrimaryIndigo,
    content: @Composable () -> Unit
) {
    val lightColors = lightColorScheme(
        primary = accentColor,
        onPrimary = Color.White,
        primaryContainer = accentColor.copy(alpha = 0.12f),
        onPrimaryContainer = accentColor,
        secondary = SkyAccent,
        onSecondary = Color.White,
        secondaryContainer = SkyAccent.copy(alpha = 0.12f),
        onSecondaryContainer = SkyAccent,
        background = Color(0xFFF8FAFC),
        onBackground = Color(0xFF0F172A),
        surface = Color.White,
        onSurface = Color(0xFF0F172A),
        surfaceVariant = Color(0xFFF1F5F9),
        onSurfaceVariant = Color(0xFF475569),
        outline = Color(0xFFCBD5E1),
        outlineVariant = Color(0xFFE2E8F0)
    )

    val darkColors = darkColorScheme(
        primary = accentColor,
        onPrimary = Color.White,
        primaryContainer = accentColor.copy(alpha = 0.25f),
        onPrimaryContainer = Color.White,
        secondary = SkyAccent,
        onSecondary = Color.White,
        secondaryContainer = SkyAccent.copy(alpha = 0.25f),
        onSecondaryContainer = Color.White,
        background = Color(0xFF0B1120),
        onBackground = Color(0xFFF8FAFC),
        surface = Color(0xFF1E293B),
        onSurface = Color(0xFFF8FAFC),
        surfaceVariant = Color(0xFF334155),
        onSurfaceVariant = Color(0xFF94A3B8),
        outline = Color(0xFF475569),
        outlineVariant = Color(0xFF334155)
    )

    MaterialTheme(
        colorScheme = if (darkTheme) darkColors else lightColors,
        typography = AppTypography,
        content = content
    )
}
