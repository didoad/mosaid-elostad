package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.TeacherRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var repository: TeacherRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext<Context>()
        repository = TeacherRepository(context)
    }

    @Test
    fun `read string from context`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("DJEMI-AI", appName)
    }

    @Test
    fun `verify serialization and deserialization for cloud sync`() {
        val serialized = repository.exportFullSerializedState()
        assertNotNull(serialized)
        assertTrue(serialized.contains("profile"))
        assertTrue(serialized.contains("criteria"))
        assertTrue(serialized.contains("sections"))

        val success = repository.applySerializedState(serialized)
        assertTrue(success)
    }

    @Test
    fun `verify assessment criteria step sizes and calculations`() {
        val defaultCriteria = repository.criteria.value
        assertTrue(defaultCriteria.isNotEmpty())
        assertEquals(4.0, defaultCriteria[0].max, 0.01)

        val step = repository.stepSize.value
        assertTrue(step == 0.25 || step == 0.5)
    }

    @Test
    fun `verify default sections and students loaded`() {
        val sections = repository.sections.value
        assertTrue(sections.isNotEmpty())

        val students = repository.studentsBySection.value[1L]
        assertNotNull(students)
        assertTrue(students!!.isNotEmpty())
    }

    @Test
    fun `verify individual assessment score modification updates gradebook row immediately`() {
        val secId = 1L
        val student = repository.studentsBySection.value[secId]?.firstOrNull()
        assertNotNull(student)
        val studentName = student!!.fullName

        // Initial gradebook activity score
        val initialGbRow = repository.gradebookBySection.value[secId]?.find { it.studentId == student.id }
        assertNotNull(initialGbRow)

        // Modify individual criterion score by +0.5
        repository.updateStudentScore(secId, studentName, 0, 0.5)

        // Verify gradebook row was updated immediately
        val updatedGbRow = repository.gradebookBySection.value[secId]?.find { it.studentId == student.id }
        assertNotNull(updatedGbRow)
        assertTrue(updatedGbRow!!.activityScore > 0.0)
    }
}
