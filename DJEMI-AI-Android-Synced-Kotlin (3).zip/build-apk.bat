@echo off
echo Building DJEMI-AI Debug and Release APKs...
where gradle >nul 2>&1
if %errorlevel%==0 (
  gradle assembleDebug assembleRelease --no-daemon
) else (
  echo Open this folder in Android Studio or push to GitHub to build via .github/workflows/build-apk.yml
  pause
  exit /b 1
)
echo APKs generated inside app\build\outputs\apk\
pause
