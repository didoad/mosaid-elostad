#!/usr/bin/env bash
set -euo pipefail
echo "Building DJEMI-AI Debug & Release APKs..."
if command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug assembleRelease --no-daemon
elif [ -x ./gradlew ]; then
  ./gradlew assembleDebug assembleRelease --no-daemon
else
  echo "Please open this folder in Android Studio or install Gradle 9.3.1 (or push to GitHub to run .github/workflows/build-apk.yml)."
  exit 1
fi
echo "APKs generated inside app/build/outputs/apk/"
